//time functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// reset all alarm settings
function AlarmReset () {
    window.clearTimeout(alarmID);	// stop running alarm sound from repeating
    alarmID = null;
    window.clearTimeout(alarmOffID);	// stop running timer to turn off alarm @ running
    alarmOffID = null;
    alarm = false;	// alarm not running
    alarmOn = false;     // for indicationif alarm is set on or off			
    alarmRinging = false;	// to prevent alarm going off again after turning off
    alarmSetting = false;       // if alarm is at set mode to make changes
//    alarmSet = "h";     // setting alarm hoors (h) or minutes (m) @ NO cursor +
    alarmSet = "m";     // setting alarm hoors (h) @ cursor +
    prefAlarmMin = 0;	// last saved alarm setting minutes
    prefAlarmHour = 0;	// last saved alarm setting hours
};

// show alarm time & on/off indication
function AlarmShow (ind) {
    AlarmShowNum();	// show alarm time
    if (ind=="on") {
        alarmOn = true;
        PicShow("AlarmStateInd", alarmStateIndPre.src); // show alarm indicator on screen
    } else {
        alarmOn = false;
        PicShow("AlarmStateInd", nullPre.src); // hide alarm indicator on screen
    };
};

// show alarm time setting
function AlarmShowNum () {
    TimeShowOnScreen(prefAlarmMin, prefAlarmHour);
};

// set the alarm
function MainAlarm () {
    if (alarm) TimeAlarmOff();	// stop alarm if running
    if (demoID) {
        clearTimeout(demoID);     // if demo was planned or running, stop sequence
        demoID = null;
    };
    if (!alarmSetting) {
        ResetAll();	// clear all pictures & variables
        alarm = false;  // alarm is not currently running
        keys = 7;	// alarm is been set
        demo = false;		// once the alarm key is hit, the demo is turned off
        PlaySound("click_", vlm);	// click sound for push button
        alarmSetting = true;
    };
    if (game!=5) {
        game = 5; // set alarm (on)
        AlarmShow("on");	// show alarm time & on indication
        TimeAlarmBackground();
    } else {
        game = 8; // set alarm (off)
        AlarmShow("off");	// show alarm time & off indication
    };	
    demoID = setTimeout("MainTimeStart()", 300000);	// start demo after 5 minutes
};

// check if its time for alarm
function TimeAlarm () {
    Time();	// get current time
    var alarmTime;
    if (hour==prefAlarmHour && min==(prefAlarmMin-1) && !alarm && alarmOn) { 
        alarm = true;
        // set start alarm at start next minute
        alarmTime = 60000-(sec*1000);
        // alarm rings at start next minute
        alarmID = setTimeout("TimeAlarmGo()", alarmTime);
        // stop alarm 30 seconds after start
        alarmOffID = setTimeout("TimeAlarmOff()", (alarmTime + 30000)); // turn alarm off after half a minute
    };
};

// function runs all the time and checks the alarm on the background
function TimeAlarmBackground () {
    if (alarmOn) {		
        TimeAlarm();	// check if its time for alarm if alarmOn
        setTimeout("TimeAlarmBackground()", 30000)	;       // check every half minute
    }; 
};

// alarm rings
function TimeAlarmGo () {
    Time();	// get current time
    PicShow("Bell", bellPre.src);   // show bell 
    if ((sec%2)==1) {	// let bell ring indicator go up and down @ alarm
        PicShow("BellUp", nullPre.src);
        PicShow("BellDown", bellDownPre.src);
        if (game!=1) PlaySoundEvenIfDemo("alarm_", vlm);	// sound for alarm if no key pressed
    } else {
        PicShow("BellUp", bellUpPre.src);
        PicShow("BellDown", nullPre.src);
    }
    alarmID = setTimeout("TimeAlarmGo()", 1000);        // repeat after a second
};

// turn running alarm off
function TimeAlarmOff () {
    if (alarmID) {
        clearTimeout(alarmID);     // if alarm was planned or running, stop sequence
        alarmID = null;
    };
    alarm = false;
    if (game==0) {	// if acl show all bells
        PicShow("BellUp", bellUpPre.src);
        PicShow("BellDown", bellDownPre.src);
    } else {
        PicShow("BellUp", nullPre.src);
        PicShow("BellDown", nullPre.src);
        PicShow("Bell", nullPre.src);
    };
};
//end time functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
