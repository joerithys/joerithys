var vlm = 1;            // sound volume 0.01-1
var preVlm = vlm;       // previous sound volume 0.01-1 to set when sound turned on again

/*------------------------------------------------------------------sound------------------------------------------------------------------*/

 function PlaySoundAlways (name, vol){
	/*
	console.log("@ PlaySoundAlways (name, vol) : ---      %c "+name+" ! %c now...",
	"background-color:purple; color:white; font-weight:bold;",
	"background-color:none; color:black; font-weight:bold;",
	"     ---"); 	// to see if sound got started
	*/
	var playPromise;	// play-preset indicator
	name+="wav";
	playPromise = document.getElementById(name).play();
	if (vol) { 
		document.getElementById(name).volume = vol;
	}
	if (playPromise !== undefined) {
		playPromise.then(_ => {
		  // playback started!
		})
		.catch(error => {
		  // play was prevented
		});
	}
}

function PlaySound (name, vol){
	if ( prefSound&&(!demo||name=="click_") ) {
		PlaySoundAlways (name, vol);
	}
}

function PlaySoundEvenIfDemo (name, vol){
	if ( prefSound ) {
		PlaySoundAlways (name, vol);
	}
}

function StopSound (name, vol){
	var playPromise;	// play-preset indicator
	name+="wav";
	playPromise = document.getElementById(name).pause();
	if (vol) { 
		document.getElementById(name).volume = vol;
	}
	if (playPromise !== undefined) {
		playPromise.then(_ => {
		  // playback stopped!
		})
		.catch(error => {
		  // stopping was prevented
		});
	}
}

//sound functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//make beep-sound
function Beep () {
    PlaySound("beep_", vlm);
};

// swich sound on/off; dont preload here
function PrefSound () {
    prefSound = !prefSound;
    PrefSoundEval();    // Show sound volume settings according to current settings
};

// Show sound settings according to current settings
function PrefSoundEval () {
    if (!prefSound) { // if sound is set to "off" 
        preVlm = vlm;   // remember last sound volume
        vlm = 0;        // set volume to 0
    } else {
        if (preVlm==0) preVlm = 0.01; // if no previous sound volume, set to minimum
        vlm = preVlm;   // set sound volume to previous setting
    };
    PrefSoundSettings();	// show sound on/off indication
    PrefSoundShow();	// show volume indicator on screen for testing purposes
    PlaySound("click_", vlm);	// click sound for slide button
};

// show/hide volume indicator for testing purposes
function PrefSoundShow () {
    var vlmTxt = "";    // empty sound volume indicator picture
    $("#SoundStateInd").html("");	// empty/hide volume indicator on screen
    if (prefSoundShow) {      // if volume indicator is set to show
        if (vlm>0.00999) {
            // count number of sound indicator bars & translate to html
            for(var i=1; i<=(vlm*100); i++) vlmTxt += '<img SRC="img/screen/volume/SoundStateInd.png" name="SoundStateInd" border=0 style="float:left">';
            $("#SoundStateInd").html(vlmTxt);	// show counted number of sound indicator bars
        } else $("#SoundStateInd").html('<img SRC="img/null.gif" name="SoundStateInd" border=0>');	// hide volume indicator
    } else {
        $("#SoundStateInd").html('<img SRC="img/null.gif" name="SoundStateInd" border=0>');	// hide volume indicator
    };
};

// show sound on/off indication according to settings
function PrefSoundSettings () {
    if (prefSound) PicShow("Sound", soundOnPre.src)	// show sond on indication
    else PicShow("Sound", soundOffPre.src);		// show sound off indication
};

// show/hide icon for alarm as set
function ShowSndIcns () {
    if (!alarmOn && game!=9) {
        PicShow("AlarmStateInd", nullPre.src);
    } else {
        PicShow("AlarmStateInd", alarmStateIndPre.src);
    };
};

// swich sound on/off; dont preload here
function SetSound (setting) {
    prefSound = setting;
    PrefSoundSettings();	// show sound on/off indication
    PlaySound("click_", vlm);	// click sound for slide button
};

// stop all playing sounds except the button click
function StopAllSound () {
    StopSound("alarm_", vlm);
    StopSound("beep_", vlm);
    StopSound("bricksFall_", vlm);
    StopSound("click_", vlm);
    StopSound("felixHit_", vlm);
    StopSound("felixMove_", vlm);
    StopSound("felixNoMove_", vlm);
    StopSound("felixTop_", vlm);
    StopSound("gameOver_", vlm);
    StopSound("invincible_", vlm);
    StopSound("invincibleDone_", vlm);
    StopSound("nothing_", vlm);
    StopSound("ralphFall_", vlm);
    StopSound("ralphImpact_", vlm);
    StopSound("ralphStamp_", vlm);
    StopSound("windowFix_", vlm);
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end sound functions


/*------------------------------------------------------------------sound------------------------------------------------------------------*/
