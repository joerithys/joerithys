//Product:                G&W Fix-it Felix HTML - New Wide Screen (Nintendo) Simulator
//Version:                1.1
//Started:                 23.06.2024
//Last update:          07.08.2024
//Author:                 Flyzy (Joeri Thys)
//Creator:                Frisky Woods
//Programmer          Flyzy (Joeri Thys)
//Original G&W:        Nintendo Co. Ltd

//Credits:
//Design, layout and artwork by Frisky Woods & Lee Robson (hydef)
//Based on scans by Sean Riddle

//initialise variables
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var blinkSpeed = 500;  // blinking speed for bonus indication
var blinkID;    // ID for timeout blinking score

var demo = false;       // indicates if demo is running or not
var demoID;     // ID for timeout demo autostart after last handling & keeping cycling
var sequence = 1;    // sequence for demo
var ralphFallSequence = 1;    // ralph falling sequence 
var ralphStartSequence = 1;    // ralph starting sequence 

var acl = false;    // for showing acl pictures, all if pressed twice fast
var aclID;    // ID to view all pictures @ fast double click
var actionPos;   // to indicate last action

var bricks = new Array();    // to show the bricks
for (i=0 ; i<3 ; i++) {     // to show the bricks on all floors
    bricks[i] = new Array();
    for (j=1 ; j<5 ; j++) {     // to show the bricks on each floor
        bricks[i][j] = 0;
    };
};
var bricksNextID;    // ID for delay on next bricksdrop
var bricksHurt = new Array();    // to indicate is the bricks are hurtfull
for (i=0 ; i<3 ; i++) {     // to indicate is the bricks are hurtfull on all floors
    bricksHurt[i] = new Array();
    for (j=1 ; j<5 ; j++) {     // to indicate is the bricks are hurtfull on each floor
        bricksHurt[i][j] = 0;
    };
};
var bricksHurtID;    // ID for timeout indicating the bricks have reached the hurtfull height
var brokenWindows;    // counted broken windows for ralph to break
var felixBlink;// counts felix's blinks
var felixBlinkID;// ID for timeout blinking felix
var game = 0;   // 0-no-game-acl-pictures; 1-gameA; 3-game-over; 4-clock; 5-alarm-on; 7-alarm-set; 8-alarm-off;
var gameOver = 0;   // game not over yet
var gameID;    // ID for timeout game sequence
var gameResetID;    // ID to clear all game delay parameter ID's
var gameSpeedMax = 500;    // maximum speed for game sequence timer
var gameSpeedMin = 1000;    // minimum speed for game sequence timer
var gameSpeed = 1000;    // speed for game sequence timer
var highScore = 0;
var invincibility = 0; // felix is not temporarily invincible
var invincibilityPie1 = 0;        // invincibilityPie1 @ bottom left not present
var invincibilityPie2 = 0;        // invincibilityPie1 @ top right not present
var life = 0;   // number of lives left
var missedID;   //      ID for missed item delay & proceed with game
var missed = false;     // indicating missed item, game paused, no action popssible
var missedBlink = 0;     // number of blinks left, indicating missed item, game paused, no action popssible
var panels = new Array();    // to show the panels
for (i=1 ; i<3 ; i++) {     // to show the panels on all floors
    panels[i] = new Array();
    for (j=1 ; j<4 ; j++) {     // to show the panels on each floor
        panels[i][j] = 0;
    };
};
var pause = false;    
var pauseID;    // ID to pause the game temporarily (pause stopper)
var posx = 1;        // horizontal position player
var posy = 1;        // vertical position player
var ralphBricksID;    // ID for ralph dropping bricks
var ralphFallID;    // ID for falling ralph
var ralphMoveID;    // ID for moving ralph
var runTime = 5;    // times to run a blink function
var windowGlass = new Array();    // to show the windows
for (i=1 ; i<3 ; i++) {     // to show the windows on all floors
    windowGlass[i] = new Array();
    for (j=1 ; j<5 ; j++) {     // to show the windows on each floor
        windowGlass[i][j] = 0;
    };
};

// reset pressed keys to none pressed
var keyDown = false;
var keyLeft = false;
var keyRight = false;
var keyUp = false;
var keyPressed = false; // indicates if a previuos direction key was already pressed to avoid double entries
var actionKeyPressed = false;    // indicates if a previuos action key was already pressed to avoid double entries
var RKeyPressed = false;    // indicates if a previuos hit "ACL" key was already pressed to avoid double entries
var TKeyPressed = false;    // indicates if a previuos hit "TIME" key was already pressed to avoid double entries

var prefSound = 1;      // 1-on; 0-off
var prefSoundShow = 0;  // show sound volume 1-on; 0-off

var pointsBonus = false;
var score = 0;    // score (all beneath 100) at init
var scoreBonus = 0;    // score bonus not added
var scoreBonusID;    // ID for timeout bonus indication blinking score

var alarm = false;    // alarm not running
var alarmID;    // ID for timeout for starting the alarm
var alarmOffID; // ID for timeout for stopping the alarm
var alarmOn = false;     // for indicationif alarm is set on or off
var alarmSetting = false;       // if alarm is at set mode to make changes
var alarmSet = "m";     // setting alarm minutes (m) @ cursor +
var cursor = true;    // cursor + present

var prefAlarmMin = 0;    // last saved alarm setting minutes
var prefAlarmHour = 0;    // last saved alarm setting hours

var timeID;     // ID for timeout time indication @ demo
var today = new Date();
var hour = today.getHours();
var min = today.getMinutes();
var sec = today.getSeconds();

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end initialise variables

//read pushed buttons & act accordingly
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
window.addEventListener("keydown", function (e) {
    codeCurrent = e.keyCode;        // for reading game keys
    e.preventDefault();        // prevent some browsers to shift, scroll, go page back or do other stuff when key pressed
    switch (e.key) {
        case "1": case"a": case"A":     // if "1", "a" or "A" pressed
            // show game button pressed
            document.images['Game A'].src = 'img/case/buttons/grey_1_flat.png';       // press button on screen
            if (!keyPressed&&!RKeyPressed&&!TKeyPressed) MainGameA(); // show high score @ play Game A after button release
            keyPressed = true;
            break;
        case "x": case "X": case "ArrowDown":    // down key released
            // show down button pressed
            document.images['Move Down'].src = 'img/case/buttons/down_flat.png';       // press button on screen
            DownPressed();      // function to move down
            keyPressed = true;
            break;
        case "s": case "S": case "ArrowLeft":    // left keys
            // show left button pressed
            document.images['Move Left'].src = 'img/case/buttons/left_flat.png';       // press button on screen
            LeftPressed();      // function to move left
            keyPressed = true;
            break;
        case "d": case "D": case "ArrowRight":    // right keys
            // show right button pressed
            document.images['Move Right'].src = 'img/case/buttons/right_flat.png';       // press button on screen
            RightPressed();     // function to move right
            keyPressed = true;
            break;
        case "e": case "E": case "ArrowUp":    // up key released
            // show up button pressed
            document.images['Move Up'].src = 'img/case/buttons/up_flat.png';       // press button on screen
            UpPressed();      // function to move up
            break;
        case "Space": case " ":    // space key
            // show action button pressed
            document.images['Action gb'].src = 'img/case/buttons/action_flat.png';     // press button on screen  
            ActionPressed();     // function to hit @ current position
            actionKeyPressed = true;
            break;
        case"r": case"R":     // if "r" or "R" pressed
            // show acl button pressed
            document.images['Acl'].src = 'img/case/buttons/acl_push.png';  // press button on screen
            TotalReset(); // show full sprites
            RKeyPressed = true;
            break;
        case"t": case"T":     // if "t" or "T" pressed
            // show time button pressed
            document.images['Time'].src = 'img/case/buttons/grey_3_flat.png';  // press button on screen
            if (!keyPressed&&!RKeyPressed&&!TKeyPressed) MainTime(); // show time & demo
            TKeyPressed = true;
            TimeShowOnScreen(prefAlarmMin, prefAlarmHour);
            break;
        case"w": case"W":     // if "w" or "W" pressed
            // show alarm button pressed
            document.images['Alarm'].src = 'img/case/buttons/grey_2_flat.png';  // press button on screen
            if (!keyPressed&&!RKeyPressed&&!TKeyPressed) MainAlarm(); // set alarm
            break;
        //test case buttons 
        case "+":    // "+"-numpadkey
            if (vlm<1) {
                vlm = (parseFloat(vlm) + 0.01).toFixed(2);    // increase volume for test purposes
                preVlm = vlm;   // current voluem becomes previus set @ next change of volume
            };
            if (vlm==0.01)  SetSound(true);    // show sound turned on
            PrefSoundShow();    // show volume indicator on screen for testing purposes
            break;
        case "-":    // "-"-key
            if (vlm>0) {
                vlm = (parseFloat(vlm) - 0.01).toFixed(2);    // decrease volume for test purposes
                preVlm = vlm;   // current voluem becomes previus set @ next change of volume
            };
            if (vlm==0) SetSound(false);    // show sound turned off
            PrefSoundShow();    // show volume indicator on screen for testing purposes
            break;
        case "/":    // "-"-key
            if (vlm==0.3) vlm = 0.03
            else vlm = 0.3;
            PrefSoundShow();    // show volume indicator on screen for testing purposes
            break;
        case "@": case String.fromCharCode(233):    // mac-"@"(at)-key/win-"é"(e-accent-egue)-key 
            prefSoundShow = !prefSoundShow;     // show/hide indicator
            PrefSoundShow();    // show volume indicator on screen for testing purposes
            break;
        case ")": case String.fromCharCode(219):
            zoomed = zoomed?0:1;
            $(function () {
                CheckSizeZoom();
                $('#divWrap').css('visibility', 'visible');
            });
            $(window).resize(CheckSizeZoom);
            break;
        default:
    };
    console.log("You pressed e.keyCode : " + e.keyCode + " <==> '" + e.key + "'                                        pause = "+pause+" --- actionKeyPressed = "+actionKeyPressed+ "'                                        score = "+score);
}, false);

window.addEventListener("keyup", function (e) {
    // game and arrow keys
    switch (e.key) {
        case "x": case "X": case "ArrowDown":    // down key released
            // show down button default
            document.images['Move Down'].src = 'img/case/buttons/down.png';       // unpress button on screen
            keyPressed = false;
            break;
        case "s": case "S": case "ArrowLeft":    // left key released
            // show left button default
            document.images['Move Left'].src = 'img/case/buttons/left.png';       // unpress button on screen
            keyPressed = false;
            break;
        case "d": case "D": case "ArrowRight":    // right key released
            // show right button default
            document.images['Move Right'].src = 'img/case/buttons/right.png';       // unpress button on screen
            keyPressed = false;
            break;
        case "e": case "E": case "ArrowUp":    // up key released
            // show up button default
            document.images['Move Up'].src = 'img/case/buttons/up.png';       // unpress button on screen
            keyPressed = false;
            break;
        case "Space": case " ":    // space key released
            // show action button default
            document.images['Action gb'].src = 'img/case/buttons/action.png';       // unpress button on screen
            actionKeyPressed = false;   
            break;
        case "1": case"a": case"A":     // if "1", "a" or "A" released
            document.images['Game A'].src = 'img/case/buttons/grey_1.png';    // unpress button on screen
            MainGameAGo(); // start running Game A
            keyPressed = false;
            break;
        case"r": case"R":     // if "r" or "R" pressed
            document.images['Acl'].src = 'img/case/buttons/acl.png';  // unpress button on screen
            RKeyPressed = false;
            break;
        case"t": case"T":     // if "t" or "T" released
            document.images['Time'].src = 'img/case/buttons/grey_3.png';  // unpress button on screen
            TKeyPressed = false;
            MainTimeStart();    // start demo
            break;
        case"w": case"W":     // if "w" or "W" pressed
            document.images['Alarm'].src = 'img/case/buttons/grey_2.png';  // unpress button on screen
            break;
        default: 
    };
}, false);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end read pushed buttons & act accordingly

// if reviewing this tab, refresh screen if necessary
$(window).focus(function(){
    //focus log code
    console.log("---      %c Window focused ! %c   ...   %c Refreching screen ... %c   --   %c Welcome back! %c          ---          "+(gameOver?"screen not refreshed because GAME OVER !!!%c%c":"%c SCREEN REFRESHED ! %c"),
                "background-color:red; color:white; font-weight:bold;",
                "background-color:none; color:black; font-weight:bold;",
                "background-color:turquoise; color:blue; font-weight:bold;",
                "background-color:none; color:black; font-weight:bold;",
                "background-color:green; color:white; font-weight:bold;",
                "background-color:none; color:black; font-weight:bold;",
                "background-color:purple; color:white; font-weight:bold;",
                "background-color:none; color:black; font-weight:bold;",
                "     ---");     // color test
});

//when page loaded focus on game 
$(document).ready(function () {
    $(function () {
        CheckSizeZoom();    // get size of browser window
        $('#divWrap').css('visibility', 'visible');
    });
    $(window).resize(CheckSizeZoom);    // set game size according to browser window
    $("#game").focus(); // get focus on the game
    PicPreload();    // this function preloads all images to make them ready for use
    MainPicturesShow();    // show all figures & "12:00"
    demoID = window.setTimeout("MainTimeStart()", 60000);    // start demo after a minute  
});

//standard functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// actually perform action (fix window)
function Action () {
    if (posy<3&&!missed&&!pause) {    // if game is running and felix not on top of the building
        WindowFix();    // fix the window @ current position
    };
};

// action (FIX-IT) button or -key pressed
function ActionPressed () {
    if (!cursor) {    //cursor + present
        if (alarmSet=="m") alarmSet = "h"
        else if (alarmSet=="h") alarmSet = "m";
    };
    if (!actionKeyPressed&&!demoID&&life>0&&!pause) {        // to avoid continious action @ running game
        Action();    // action (fix window)
        actionKeyPressed = true;
    };
};

// go down @ game or change alarm hour if alarm is being set
function Down () {
    if (game==1&&!pause) {    // if game playing
        if (posy>1&&posy<3&&!missed) {    // if not totally down or up and game still running
            GoDown();    // go position down
            if (bricks[1][posx]&&!invincibility)     {  // if hitting bricks while not invincible
                pause = true;
                PlaySound("felixHit_", vlm);    // sound for felix getting hit
                Missed();    // process miss variables and continue 
            } else { 
                if (bricksHurt[posy][posx]&&!invincibility)     {  // if hitting bricks while not invincible
                    pause = true;
                    PlaySound("felixHit_", vlm);    // sound for felix getting hit
                    Missed();    // process miss variables and continue 
                } else {
                    if (posy==1&&posx==4&&invincibilityPie1) {   // if felix is @ same place as invicibilityPie 1
                        invincibilityPie1 = 0;    // invicibilityPie 1 is gone
                        InvincibilityPiesShow();    // show invicibilityPie 1 is gone
                        invincibility = 1;    // felix is temporarily invincible
                        PlaySound("invincible_", vlm);    // sound for felix getting temporarily invincibility
                        felixBlink = 1;        // start of felixblink
                        FelixBlink();    // let felix blink while felix is invincible
                    } else PlaySound("felixMove_", vlm);    // sound for felix moving
                };
            };
        };
    } else {
        if (game==5 || game==8) {    // change the alarm time
            prefAlarmHour--;    // subtract an from hour alarm setting
            if (prefAlarmHour==-1) prefAlarmHour = 23;
            AlarmShowNum();    // show alarm time
        };
    };
};

// down button or -key pressed
function DownPressed () {
    if (!keyPressed&&(!demoID||game==5||game==8)&&(life>0||game!=1)) { // if game still running or alarm being set
        Down();    // go down @ game or change alarm hour if alarm is being set
        keyPressed = true;
    };
};

// actually go to down
function GoDown () {
    PicShow("Felix_"+eval(posy)+"_"+eval(posx), nullPre.src);    // hide felix on this position
    posy--;    // go position to the down
    FelixShow();
};

// actually go to the left
function GoLeft () {
    PicShow("Felix_"+eval(posy)+"_"+eval(posx), nullPre.src);    // hide felix on this position
    posx--;    // go position to the left
    FelixShow();
};

// actually go to the right
function GoRight () {
    PicShow("Felix_"+eval(posy)+"_"+eval(posx), nullPre.src);    // hide felix on this position
    posx++;    // go position to the right
    FelixShow();
};

// actually go up
function GoUp () {
    PicShow("Felix_"+eval(posy)+"_"+eval(posx), nullPre.src);    // hide felix on this position
    posy++;    // go position to the up
    FelixShow();
};

// go left @ game or change alarm hour or minutes if alarm is being set
function Left () {
    if (game==1&&!pause) {    // if game playing
        if (!NoPanel(-1)) PlaySound("felixNoMove_", vlm);    // sound for felix not moving because of a panel
        else { 
            if (posx>1&&posy<3) {    // if not totally left or up
                GoLeft();    // go position to the left
                if (bricksHurt[posy][posx]&&!invincibility)     {  // if hitting bricks while not invincible
                    pause = true;
                    PlaySound("felixHit_", vlm);    // sound for felix getting hit
                    Missed();    // process miss variables and continue 
                } else {
                    if (posy==2&&posx==1&&invincibilityPie2) {
                        invincibilityPie2 = 0;    // eat invincibility pie
                        InvincibilityPiesShow();  // invincibilityPie 2 gone
                        invincibility = 1;    // felix temporarily invincible
                        PlaySound("invincible_", vlm);    // sound for felix getting temporarily invincibility
                        felixBlink = 1;        // start of felixblink
                        FelixBlink();
                    } else PlaySound("felixMove_", vlm);    // sound for felix moving
                };
            };
        };
    } else {
        if (game==5 || game==8) {    // change the alarm time
            if (alarmSet=="m") {    // change minutes of alarm time
                prefAlarmMin--;    // subtract a minute from alarm time
                if (prefAlarmMin==-1) prefAlarmMin = 59;
                AlarmShowNum();    // show alarm time
            } else if (alarmSet=="h") {    // add an hour to alarm time
                prefAlarmHour--;    // subtract an from hour alarm setting
                if (prefAlarmHour==-1) prefAlarmHour = 23;
                AlarmShowNum();    // show alarm time
            };
        };
    };
};

//--------------------------------------------------------------------

// left button or -key pressed
function LeftPressed () {
    if (!keyPressed&&(!demoID||game==5||game==8)&&(life>0||game!=1)) { // if game still running or alarm being set
        Left();    // go left @ game or change alarm hour or minutes if alarm is being set
        keyPressed = true;
    };
};

// make an array
function MakeArray (size) {
    this.length = size;
    for(var i=1; i<=size; i++) this[i] = 0;
};

// show/hide figure on screen
function PicShow (id, name) {
    if (name) document.images[id].src = name;    // if picture given assign it to the figure
};

// go right @ game or change alarm hour or minutes if alarm is being set
function Right () {
    if (game==1&&!pause) {    // if game playing
        if (!NoPanel(0)) PlaySound("felixNoMove_", vlm);    // sound for felix not moving because of a panel
        else {
            if (posx<4&&posy<3) {    // if not totally right or up
                GoRight ();    // go position to the right
                if (posx==3&&posy==2&&panels[1][3]&&windowGlass[1][4]) {    // if felix might get in the right bottom corner
                    invincibilityPie1= 1;        // to show invincibilityPie 1 
                    InvincibilityPiesShow();        // to show present invincibilityPies
                };
                if (bricksHurt[posy][posx]&&!invincibility)     {  // if hitting bricks while not invincible
                    pause = true;
                    PlaySound("felixHit_", vlm);    // sound for felix getting hit
                    Missed();    // process miss variables and continue 
                } else {
                    if (posy==1&&posx==4&&invincibilityPie1) {
                        invincibilityPie1 = 0;    // eat invincibility pie
                        InvincibilityPiesShow();  // invincibilityPie 1 gone
                        invincibility = 1;    // felix temporarily invincible
                        PlaySound("invincible_", vlm);    // sound for felix getting temporarily invincibility
                        felixBlink = 1;    // start of felix blink during his invincibility
                        FelixBlink();    // let felix blink during his invincibility
                    } else PlaySound("felixMove_", vlm);    // sound for felix moving
                };
            };
        };
    } else {
        if (game==5 || game==8) {    // change the alarm time
            if (alarmSet=="m") {    // change minutes of alarm time
                prefAlarmMin++;    // add a minute to alarm time
                if (prefAlarmMin==60) prefAlarmMin=0;
                AlarmShowNum();    // show alarm time
            } else if (alarmSet=="h") {    // change minutes of alarm time
                prefAlarmHour++;    // add an hour to alarm setting
                if (prefAlarmHour==24) prefAlarmHour = 0;
                AlarmShowNum();    // show alarm time
            };
        };
    };
};

// right button or -key pressed
function RightPressed () {
    if (!keyPressed&&(!demoID||game==5||game==8)&&(life>0||game!=1)) {  // if game still running or alarm being set
        Right();    // go right @ game or change alarm hour or minutes if alarm is being set
        keyPressed = true;
    };
};

// go up @ game or change alarm hour if alarm is being set
function Up () {
    if (game==1&&!pause&&posy<3) {    // if game playing and felix not yet on top of the building
        if (posy==1||(posy==2&&WindowsFixed())) {    // if on first floor or on second floor and all windows are fixed
            if (bricks[posy][posx]&&!invincibility)     {  // if hitting bricks while not invincible
                pause = true;
                PlaySound("felixHit_", vlm);    // sound for felix getting hit
                Missed();    // process miss variables and continue 
            } else { 
                GoUp ();    // go position up
                if (posx==3&&posy==2&&panels[1][3]&&windowGlass[1][4]) {    // if felix might get trapped in the right bottom corner
                    invincibilityPie1= 1;        // to show invincibilityPie 1 
                    InvincibilityPiesShow();        // to show present invincibilityPies
                };
                if (posy==3) { 
                    if (ralphMoveID) {
                        window.clearTimeout(ralphMoveID);    // reset ID for moving ralph
                        ralphMoveID = null;
                    };
                    BricksClear();    // remove the present bricks 
                    ScoreAdd(10);    // 10 points earned for reaching top of the building
                    pause = true;
                    ralphFallSequence = 1;    // set first step for falling ralph
                    PlaySound("felixTop_", vlm);    // sound for felix arriving on top of the building
                    ralphMoveID = window.setTimeout("RalphFall()", 1000);    // start ralph falling in half a second
                } else {
                    if (bricksHurt[posy][posx]&&!invincibility)     {  // if hitting bricks while not invincible
                        pause = true;
                        PlaySound("felixHit_", vlm);    // sound for felix getting hit
                        Missed();    // process miss variables and continue 
                    } else {
                        if (posy==2&&posx==1&&invincibilityPie2) {
                            invincibilityPie2 = 0;    // eat invincibility pie
                            InvincibilityPiesShow();  // invincibilityPie 2 gone
                            invincibility = 1;    // felix temporarily invincible
                            PlaySound("invincible_", vlm);    // sound for felix getting temporarily invincibility
                            felixBlink = 1;    // start of felix blink during his invincibility
                            FelixBlink();    // let felix blink during his invincibility
                        } else PlaySound("felixMove_", vlm);    // sound for felix moving
                    };
                };
            };
        };
    } else {
        if (game==5 || game==8) {    // change the alarm time
            prefAlarmHour++;    // add an hour to alarm setting
            if (prefAlarmHour==24) prefAlarmHour = 0;
            AlarmShowNum();    // show alarm time
        };
    };
};

// up button or -key pressed
function UpPressed () {
    if (!keyPressed&&(!demoID||game==5||game==8)&&(life>0||game!=1)) {  // if game still running or alarm being set
        Up();    // go up @ game or change alarm hour if alarm is being set
        keyPressed = true;
    };
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end standard functions

//preload screen figures & show/hide all of them
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// this function preloads all images
function PicPreload () {
    alarmStateIndPre = new Image();
    alarmStateIndPre.src = "img/screen/alarmStateInd.png";    // to show if alarm is set on or off
    bellDownPre = new Image();
    bellDownPre.src = "img/screen/bellDown.png";    // to show ringing bell in down-state @ alarm
    bellPre = new Image();
    bellPre.src = "img/screen/bell.png";    // to show bell @ alarm
    bellUpPre = new Image();
    bellUpPre.src = "img/screen/bellUp.png";    // to show ringing bell in up-state @ alarm
    bricksPre = new Array();
    for (i=0 ; i<3 ; i++) {     // to show the falling bricks on all floors
        bricksPre[i] = new Array();
        for (j=1 ; j<5 ; j++) {     // to show the falling bricks on each floor
            bricksPre[i][j] = new Image();
            bricksPre[i][j].src = "img/screen/bricks_"+eval(i)+"_"+eval(j)+".png";
        };
    };
    felixPre = new Array();
    for (i=1 ; i<3 ; i++) {     // to show Felix on all floors
        felixPre[i] = new Array();
        for (j=1 ; j<5 ; j++) {     // to show Felix on each floor
            felixPre[i][j] = new Image();
            felixPre[i][j].src = "img/screen/felix_"+eval(i)+"_"+eval(j)+".png";
        };
    };
    felixTopPre = new Image();
    felixTopPre.src = "img/screen/felixTop.png";    // to show Felix on top
    impact1Pre = new Image();
    impact1Pre.src = "img/screen/impact_1.png";    // to show impact 1 when Ralph fell down the building
    impact2Pre = new Image();
    impact2Pre.src = "img/screen/impact_2.png";    // to show impact 2 when Ralph fell down the building
    invincibilityPie1Pre = new Image();
    invincibilityPie1Pre.src = "img/screen/invincibilityPie_1.png";    // to show invincibilityPie 1 
    invincibilityPie2Pre = new Image();
    invincibilityPie2Pre.src = "img/screen/invincibilityPie_2.png";    // to show invincibilityPie 2 
    panelPre = new Image();
    panelPre.src = "img/screen/panel.png";    // to show the panels on the building     
    peopleTopPre = new Image();
    peopleTopPre.src = "img/screen/peopleTop.png";    // to show people on top of the building
    ralphDownPre = new Image();
    ralphDownPre.src = "img/screen/ralphDown.png";    // to show Ralph falling down the building
    ralphTopPre = new Image();
    ralphTopPre.src = "img/screen/ralphTop.png";    // to show Ralph's torso on top of the building
    ralphTopLeftLegDownPre = new Image();
    ralphTopLeftLegDownPre.src = "img/screen/ralphTopLeftLegDown.png";    // to show Ralph's left leg down on top of the building
    ralphTopLeftLegUpPre = new Image();
    ralphTopLeftLegUpPre.src = "img/screen/ralphTopLeftLegUp.png";    // to show Ralph's left leg up on top of the building
    ralphTopRightLegDownPre = new Image();
    ralphTopRightLegDownPre.src = "img/screen/ralphTopRightLegDown.png";    // to show Ralph's right leg down on top of the building
    ralphTopRightLegUpPre = new Image();
    ralphTopRightLegUpPre.src = "img/screen/ralphTopRightLegUp.png";    // to show Ralph's right leg up on top of the building
    windowPre = new Array();
    for (i=1 ; i<3 ; i++) {     // to show the windows on all floors
        windowPre[i] = new Array();
        for (j=1 ; j<5 ; j++) {     // to show the windows on each floor
            if (i==2&&j==2) { // (the two-pieced window)
                windowPre[i][j] = new Array();
                windowPre[i][j][1] = new Image();
                windowPre[i][j][1].src = "img/screen/window_"+eval(i)+"_"+eval(j)+"_"+eval(1)+".png";    // to show top piece
                windowPre[i][j][2] = new Image();
                windowPre[i][j][2].src = "img/screen/window_"+eval(i)+"_"+eval(j)+"_2.png";    // to show bottom piece
            } else { // all single-pieced windows
                windowPre[i][j] = new Image();
                windowPre[i][j].src = "img/screen/window_"+eval(i)+"_"+eval(j)+".png";
            };
        };
    };
    missPre = new Image();
    missPre.src = "img/screen/miss.png";    // to show misses
    missTxtPre = new Image();
    missTxtPre.src = "img/screen/misstxt.png";    // to show missed text
    nullPre = new Image();
    nullPre.src = "img/null.gif";    // empty picture to hide any figure
    numPre = new Array();
    for (i=1 ; i<11 ; i++) {     // to show the 10 numbers fot score/time
        numPre[i] = new Image();
        numPre[i].src = "img/screen/num"+eval(i-1)+".png";
    };
    numColonPre = new Image();
    numColonPre.src = "img/screen/num_colon.png";    // to show time splitter colon
    soundOnPre = new Image();
    soundOnPre.src = "img/case/buttons/butOn.png";    // to show sound button in on-state
    soundOffPre = new Image();
    soundOffPre.src = "img/case/buttons/butOff.png";    // to show sound button in off-state
};

// hide all figures
function AllPicturesClear () {
    for (i=1 ; i<4 ; i++) PicShow("Miss"+eval(i)+"", nullPre.src);    // hide all misses
    PicShow("Misstxt", nullPre.src);    // hide miss text
    // hide alarm figures
    PicShow("BellUp", nullPre.src);
    PicShow("BellDown", nullPre.src);
    PicShow("Bell", nullPre.src);
    PicShow("AlarmStateInd", nullPre.src);
    
    for (i=1 ; i<3 ; i++) {     // to hide Felix on all floors
        for (j=1 ; j<5 ; j++) {     // to hide Felix on each floor
            PicShow("Felix_"+eval(i)+"_"+eval(j), nullPre.src);
        };
    };
    PicShow("FelixTop", nullPre.src);        // to hide Felix on top of the building
    PicShow("Impact1", nullPre.src);    // to hide impact 1 when Ralph fell down the building
    PicShow("Impact2", nullPre.src);    // to hide impact 2 when Ralph fell down the building
    PicShow("InvincibilityPie1", nullPre.src);    // to hide invincibilityPie 1 
    PicShow("InvincibilityPie2", nullPre.src);    // to hide invincibilityPie 2 
    for (i=0 ; i<3 ; i++) {     // to hide the falling bricks on all floors
        for (j=1 ; j<5 ; j++) {     // to hide the falling bricks on each floor
            PicShow("Bricks_"+eval(i)+"_"+eval(j), nullPre.src);
        };
    };
    for (i=1 ; i<3 ; i++) {     // to hide the panels on all floors
        for (j=1 ; j<4 ; j++) {     // to hide all panels on each floor
            PicShow("Panel_"+eval(i)+"_"+eval(j), nullPre.src);    
        };
    };
    PicShow("PeopleTop", nullPre.src);        // to hide the people on top of the building
    PicShow("RalphDown", nullPre.src);    // to hide Ralph falling down the building
    PicShow("RalphTop", nullPre.src);    // to hide Ralph's torso on top of the building
    PicShow("RalphTopLeftLegDown", nullPre.src);    // to hide Ralph's left leg down on top of the building
    PicShow("RalphTopLeftLegUp", nullPre.src);// to hide Ralph's left leg up on top of the building
    PicShow("RalphTopRightLegDown", nullPre.src);    // to hide Ralph's right leg down on top of the building
    PicShow("RalphTopRightLegUp", nullPre.src);    // to hide Ralph's right leg up on top of the building
    WindowsHide();    // hide all broken windows
    PicShow("NumColon", nullPre.src);    // hide ":"
    for (i=1 ; i<5 ; i++) PicShow("Num"+eval(i)+"", nullPre.src);    // hide score/time numbers
};

// show all figures
function AllPicturesShow () {
    MainPicturesShow();    // show all figures & "12:00"
    for (i=1 ; i<5 ; i++) PicShow("Num"+eval(i)+"", numPre[9].src);    // "8"
};

// remove the present bricks 
function BricksClear () {
    for (i=0 ; i<3 ; i++) {     // to clear the bricks on all floors
        for (j=1 ; j<5 ; j++) {     // to clear the bricks on each floor
            bricks[i][j] = 0;    // no bricks on this position
            bricksHurt[i][j] = 0;    // no hurting bricks on this position
        };
    };
};

// let the present bricks drop one position
function BricksDrop () {
    if (bricksHurtID) {
        window.clearTimeout(bricksHurtID);    // reset ID for timeout indicating the bricks have reached the hurtfull height
        bricksHurtID = null;
    };
    for (i=0 ; i<3 ; i++) {     // to set the bricks on all floors
        for (j=1 ; j<5 ; j++) {     // to set the bricks on each floor
            bricksHurt[i][j] =  0;        // no bricks can hurt @ moment of drop
            if (i<2) { 
                bricks[i][j] =  bricks[(i+1)][j];    // drop brick above one position down
                bricksHurtID = window.setTimeout("BricksHurtSet("+i+","+j+");", (gameSpeed/2));    // indicating the bricks have reached the hurtfull height & see if felix can get hurt after half game speed
            } else {
                bricks[i][j] =  0;    // no bricks on this top position
                bricksHurt[i][j] =  0;    // no hurting bricks on this top position
            };
        };
    };
    BricksShow();    // show the present bricks
};

// indicating the bricks have reached the hurtfull height & see if felix gets hurt
function BricksHurtSet (i,j) {
    bricksHurt[i][j] =  bricks[i][j];    // dropped set of bricks low enough to hurt felix
    if (posy<3&&!invincibility&&bricks[posy][posx]&&posy==i&&posx==j&&!missed) {    // if felix is hit
        PlaySound("felixHit_", vlm);    // sound for felix getting hit
        Missed();    // process miss variables and continue 
    };
};

// determin to set 1 or 2 sets of bricks to drop, and show them
function BricksNext () {
    if (score<1000) BricksSet(1)   // first 1000 points, one set of bricks will drop
    else BricksSet(2);    // two sets of bricks can be dropped
};

// delete the present bricks and hide them
function BricksReset () {
    BricksClear();    // remove the present bricks 
    BricksShow();    // show the bricks not present
};

// set the next set(s) bricks to drop
function BricksSet (bricksNum) {
    var newBricksPlace1;    // first set of bricks
    var newBricksPlace2;    // second set of bricks for score above 1000 points
    do {        // choose first random brick drop place not above previous one
         newBricksPlace1 = Math.floor(4*Math.random())+1;
    } while (bricks[2][newBricksPlace1]);
    do {        // choose second random brick drop place not above previous one
         newBricksPlace2 = Math.floor(4*Math.random())+1;
    } while (bricks[2][newBricksPlace2]);
    newBricksPlace2 = (bricksNum==1||newBricksPlace2==newBricksPlace1)?0:newBricksPlace2;    // if one asked or if both are same, one set counts
    var left = (newBricksPlace1<3?newBricksPlace1:0)+(newBricksPlace2<3?newBricksPlace2:0);    // left position 1 or 2 of bricks
    var right = (newBricksPlace1>2?(newBricksPlace1-2):0)+(newBricksPlace2>2?(newBricksPlace2-2):0);    // right position 1 or 2 of bricks
    RalphBricks (left,right);    // put ralph on top of the building with leg(s) up where bricks will drop
};

// show the present bricks
function BricksShow () {
    for (i=0 ; i<3 ; i++) {     // to show the bricks on all floors
        for (j=1 ; j<5 ; j++) {     // to show the bricks on each floor
            if (bricks[i][j]) PicShow("Bricks_"+eval(i)+"_"+eval(j), bricksPre[i][j].src)    // show bricks if present
            else PicShow("Bricks_"+eval(i)+"_"+eval(j), nullPre.src);    // hide bricks
        };
    };
};

// hide Felix @ any position on the building
function FelixHide () {
    for (i=1 ; i<3 ; i++) {     // to hide Felix on all floors
        for (j=1 ; j<5 ; j++) {     // to hide Felix on each floor
            PicShow("Felix_"+eval(i)+"_"+eval(j), nullPre.src);
        };
    };
};

// hide Felix @ current position
function FelixTopHide () {
    PicShow("FelixTop", nullPre.src);
};

// show Felix @ current position
function FelixShow () {
    if (posy<3)
        PicShow("Felix_"+eval(posy)+"_"+eval(posx), felixPre[posy][posx].src);    // to show Felix @ current position on the building
    else 
        PicShow("FelixTop", felixTopPre.src);        // to show Felix on top of the building
};

// reset and hide the present invincibility pies
function InvincibilityPiesReset () {
    invincibilityPie1 = 0;        // no invincibilityPie1 @ bottom right not present
    invincibilityPie2 = 0;        // no invincibilityPie1 @ top left not present
    InvincibilityPiesShow();        // to show present invincibilityPies not present
};

// show the present invincibility pies
function InvincibilityPiesShow () {
    if (invincibilityPie1) PicShow("InvincibilityPie1", invincibilityPie1Pre.src)        // show invincibilityPie 1 if present
    else PicShow("InvincibilityPie1", nullPre.src)        // hide invincibilityPie 1 
    if (invincibilityPie2) PicShow("InvincibilityPie2", invincibilityPie2Pre.src);        // show invincibilityPie 2 if present
    else PicShow("InvincibilityPie2", nullPre.src);        // hide invincibilityPie 2 
};

// show default pictures for demo
function MainPicturesDefault () {
    BricksReset();        // delete the present bricks and hide them
    FelixHide();        // hide Felix @ any position on the building
    PanelsReset();        // delete the present panels
    PicShow("PeopleTop", nullPre.src);        // hide the people on top of the building
    posx = 1;    // felix on ground floor
    posy = 1;    // felix on first position of this floor
    FelixShow();        // show felix @ new position
    RalphTopShow(0,0);        // show Ralph on top legs down
    WindowsClear();    // unset all present windows 
    // show some broken windows
    windowGlass[1][2] = 1;    // second window bottom floor
    windowGlass[1][4] = 1;    // fourth window bottom floor
    windowGlass[2][1] = 1;    // first window top floor
    windowGlass[2][3] = 1;    // third window top floor
    WindowsShow();        // show current broken windows
};

// show default pictures as @ start of the game
function MainPicturesGame () {
    BricksReset();        // delete and hide the present bricks
    FelixHide();        // hide Felix @ any position on the building
    FelixTopHide();        // hide Felix on top of the building
    InvincibilityPiesReset();    // reset and hide the present invincibility pies
    PanelsSet();    // set panels according to score
    PicShow("PeopleTop", nullPre.src);        // hide the people on top of the building
    RalphTopShow(0,0);        // show Ralph on top of the building legs down
    WindowsSet();    // prepare new broken windows for the game
    WindowsHide();    // hide all broken windows for ralph to break them
};

// show all figures & "12:00"
function MainPicturesShow () {
    MissedShow();    // show misses & txt 
    PicShow("BellUp", bellUpPre.src);    // blank (to hide honk)
    PicShow("BellDown", bellDownPre.src);    // honk
    PicShow("Bell", bellPre.src);    // blank, race car already there
    PicShow("AlarmStateInd", alarmStateIndPre.src);    // alarm indicator (race car)
    for (i=0 ; i<3 ; i++) {     // to show the falling bricks on all floors
        for (j=1 ; j<5 ; j++) {     // to show the falling bricks on each floor
            PicShow("Bricks_"+eval(i)+"_"+eval(j), bricksPre[i][j].src);
        };
    };
    for (i=1 ; i<3 ; i++) {     // to show Felix on all floors
        for (j=1 ; j<5 ; j++) {     // to show Felix on each floor
            PicShow("Felix_"+eval(i)+"_"+eval(j), felixPre[i][j].src);
        };
    };
    PicShow("FelixTop", felixTopPre.src);        // to show Felix on top of the building
    PicShow("Impact1", impact1Pre.src);    // to show impact 1 when Ralph fell down the building
    PicShow("Impact2", impact2Pre.src);    // to show impact 2 when Ralph fell down the building
    PicShow("InvincibilityPie1", invincibilityPie1Pre.src);        // to show invincibilityPie 1 
    PicShow("InvincibilityPie2", invincibilityPie2Pre.src);        // to show invincibilityPie 2 
    for (i=1 ; i<3 ; i++) {     // to show the panels on all floors
        for (j=1 ; j<4 ; j++) {     // to show all panels on each floor
            PicShow("Panel_"+eval(i)+"_"+eval(j), panelPre.src);    
        };
    };
    PicShow("PeopleTop", peopleTopPre.src);        // to show the people on top of the building
    PicShow("RalphDown", ralphDownPre.src);    // to show Ralph falling down the building
    PicShow("RalphTop", ralphTopPre.src);    // to show Ralph's torso on top of the building
    PicShow("RalphTopLeftLegDown", ralphTopLeftLegDownPre.src);    // to show Ralph's left leg down on top of the building
    PicShow("RalphTopLeftLegUp", ralphTopLeftLegUpPre.src);// to show Ralph's left leg up on top of the building
    PicShow("RalphTopRightLegDown", ralphTopRightLegDownPre.src);    // to show Ralph's right leg down on top of the building
    PicShow("RalphTopRightLegUp", ralphTopRightLegUpPre.src);    // to show Ralph's right leg up on top of the building
    for (i=1 ; i<3 ; i++) {     // to show the windows on all floors
        for (j=1 ; j<5 ; j++) {     // to show the windows on each floor
            if (i==2&&j==2) {  // the two-pieced window
                PicShow("Window_"+eval(i)+"_"+eval(j)+"_"+eval(1), windowPre[i][j][1].src);    // show top piece
                PicShow("Window_"+eval(i)+"_"+eval(j)+"_2", windowPre[i][j][2].src);    // show bottom piece
            } else  // all single-pieced windows
                PicShow("Window_"+eval(i)+"_"+eval(j), windowPre[i][j].src);
        };
    };
    PicShow("NumColon", numColonPre.src);       // ":"
    PicShow("Num1", numPre[2].src);     // 1
    PicShow("Num2", numPre[3].src);     // 2
    PicShow("Num3", numPre[1].src);     // 0
    PicShow("Num4", numPre[1].src);     // 0
};

// hide misses 
function MissHide () {
    for (var i=1 ; i<4 ; i++) PicShow("Miss"+eval(i)+"", nullPre.src);
};

// show all misses  & miss text
function MissedShow () {
    for (i=1 ; i<(4-life) ; i++) {    // for lives lost
        PicShow("Miss"+eval(i)+"", missPre.src);    // show miss
     };
     if (3-life) PicShow("Misstxt", missTxtPre.src);    // if miss, show miss text
};

// hide "MISS" text
function MissTextHide () {
    PicShow("Misstxt", nullPre.src);
};

// check if no pannel stands in the way
function NoPanel (direction) {
    var noPanel = true;
    if (((direction&&posx>1)||(!direction&&posx<4))&&(panels[posy][(posx+direction)])) noPanel = false;  // if felix hits panel
    return noPanel;
}

// set partial or full set of panels according to score
function PanelsChoose (num,full) {
    var panelx;    // horizontal position of chosen panel
    var panely;    // vertical position of chosen panel
    for (i=1 ; i<(num+1) ; i++) {
        do {        // set chosen number of panels
            panelx = num==3?i:(Math.floor(3*Math.random())+1);    // if 3 palels demanded set 1 on 1 column, else randomly
            panely = Math.floor(2*Math.random())+1;
        } while ((panels[1][panelx]||panels[2][panelx])&&full);    // as long as panel already up or on top and full set demanded
        if (!((panels[1][panelx]||panels[2][panelx])&&!full)) {
            panels[panely][panelx] = 1;
        };
    };
    if (panels[1][1]) {    // if felix might get in the left bottom corner @ the beginning of the level
        invincibilityPie2= 1;        // set invincibilityPie 2 
        InvincibilityPiesShow();        // show present invincibilityPies
    };
};

// delete the present panels
function PanelsReset () {
    for (i=1 ; i<3 ; i++) {     // to delete the panels on all floors
        for (j=1 ; j<4 ; j++) {     // to delete the panels on each floor
            panels[i][j]  = 0;
        };
    };
};

// show the present panels
function PanelsShow () {
    for (i=1 ; i<3 ; i++) {     // to show the panels on all floors
        for (j=1 ; j<4 ; j++) {     // to show the panels on each floor
                if (panels[i][j]) {
                    PicShow("Panel_"+eval(i)+"_"+eval(j), panelPre.src);    // show panel if present
                } else {
                    PicShow("Panel_"+eval(i)+"_"+eval(j), nullPre.src);    // hide panel if not present
                 };
        };
    };
};

/// set panels according to score (every 1000 points and above 100 points)
function PanelsSet () {
    PanelsReset();        // delete the present panels
    switch (true) {
        case (score%1000>700): // 
            PanelsChoose (3,1)    // put 3 panel in a random place
            break;
        case (score%1000>500): // 
            PanelsChoose (3,0)    // put 1 to 3 panels in a random place
            break;
        case (score%1000>400): // 
            PanelsChoose (2,1)    // put 2 panels in a random place
            break;
        case (score%1000>300): // 
            PanelsChoose (2,0)    // put 1 or 2 panels in a random place
            break;
       case (score%1000>100): // 
            PanelsChoose (1,1)    // put 1 panel in a random place
            break;
       default: 
    }
    if (score>100) PanelsShow();    // show chosen panels
};

// ralph lifts leg(s) and stamps to drop bricks
function RalphBricks (left,right) {
    if (ralphBricksID) {
        window.clearTimeout(ralphBricksID);    // reset ID for ralph dropping bricks
        ralphBricksdID = null;
    };
    RalphTopShow((left?1:0),(right?1:0));        // show Ralph on top of building, legs as parameters demand
    ralphBricksID = window.setTimeout("RalphBricksSet("+left+","+right+");", (gameSpeed/2));    // places the next dropping bricks with a footstamp in half a gameSpeed seconds
};

// ralph stamps foot/feet & drops bricks
function RalphBricksSet (left,right) {
    if (!pause&&!gameOver) {
        RalphTopShow(0,0);        // show Ralph on top of the building legs down
        PlaySound("ralphStamp_", vlm);    // sound for ralph stamping his feet
        switch(left) {    // left foot stamped
            case (1): // 
                bricks[2][1] = 1;    // show top bricks @ 1th window
                bricksHurtID = window.setTimeout("BricksHurtSet(2,1);", (gameSpeed/2));    // indicating the bricks have reached the hurtfull height & see if felix gets hurt
                break;
            case (2): // 
                bricks[2][2] = 1;    // show top bricks @ 2nd window
                bricksHurtID = window.setTimeout("BricksHurtSet(2,2);", (gameSpeed/2));    // indicating the bricks have reached the hurtfull height & see if felix gets hurt
                break;
            case (3): // 
                bricks[2][1] = 1;    // show top bricks @ 1th window
                bricks[2][2] = 1;    // show top bricks @ 2nd window
                bricksHurtID = window.setTimeout("BricksHurtSet(2,1); BricksHurtSet(2,2);", (gameSpeed/2));    // indicating the bricks have reached the hurtfull height & see if felix gets hurt
                break;
              default: 
        };
        switch(right) {    // right foot stamped
            case (1): // 
                bricks[2][3] = 1;    // show top bricks @ 3rd window
                bricksHurtID = window.setTimeout("BricksHurtSet(2,3);", (gameSpeed/2));    // indicating the bricks have reached the hurtfull height & see if felix gets hurt
                break;
            case (2): // 
                bricks[2][4] = 1;    // show top bricks @ 4th window
                bricksHurtID = window.setTimeout("BricksHurtSet(2,4);", (gameSpeed/2));    // indicating the bricks have reached the hurtfull height & see if felix gets hurt
                break;
            case (3): // 
                bricks[2][3] = 1;    // show top bricks @ 3rd window
                bricks[2][4] = 1;    // show top bricks @ 4th window
                bricksHurtID = window.setTimeout("BricksHurtSet(2,3); BricksHurtSet(2,4);", (gameSpeed/2));    // indicating the bricks have reached the hurtfull height & see if felix gets hurt
                break;
           default: 
        };
    };
    BricksShow();    // show the present bricks
};

// ralph falls down the building
function RalphFall () {
    if (ralphFallID) {
        window.clearTimeout(ralphFallID);    // reset ID for ralph falling
        ralphFallID = null;
    };
    switch(ralphFallSequence) { 
        case 1: 
            RalphTopHide();        // hide Ralph on top of the building
            PicShow("PeopleTop", peopleTopPre.src);        // show the people on top of the building
            PicShow("RalphDown", ralphDownPre.src);    // show Ralph falling down the building
            PlaySound("ralphFall_", vlm);    // sound for ralph falling
            break;
        case 2: 
            PicShow("RalphDown", nullPre.src);    // hide Ralph falling down the building
            PicShow("Impact1", impact1Pre.src);    // show impact 1 when Ralph fell down the building
            PlaySound("ralphImpact_", vlm);    // sound for ralph hittng the floor
            break;
        case 3:  
            PicShow("Impact2", impact2Pre.src);    // show impact 2 when Ralph fell down the building                        
            break;
        case 4: 
            PicShow("Impact2", nullPre.src);    // hide impact 2 when Ralph fell down the building                        
            break;
        case 5:  
            PicShow("Impact1",nullPre.src);    // hide impact 1 when Ralph fell down the building
            break;
        default: 
    };    
    ralphFallSequence++;    // next step
    if (ralphFallSequence<6) ralphFallID = window.setTimeout("RalphFall()", 500)    // start next sequence of ralph falling in half a second
    else GameGoNext();    // resume game after end of level
};

// ralph starts every level of the game by wrecking a number windows, depending on the score
function RalphStart () {
    if (game==1) {    // if game is running
        if (ralphMoveID) {
            window.clearTimeout(ralphMoveID);    // reset ID for moving ralph
            ralphMoveID = null;
        };
        switch(ralphStartSequence) { 
            case 1: 
                RalphTopShow(1,1);        // show Ralph on top of the building both legs up
                break;
           case 2:  
                RalphTopShow(0,0);        // show Ralph on top legs down
                PlaySound("ralphStamp_", vlm);    // sound for ralph stamping his feet
                WindowBreak(1);    // show the next broken window
                break;
            case 3:    
                RalphTopShow(1,1);        // show Ralph on top of the building both legs up
                break;
            case 4:  
                RalphTopShow(0,1);        // show Ralph on top of the building right leg up
                PlaySound("ralphStamp_", vlm);    // sound for ralph stamping his feet
                WindowBreak(2);    // show the next broken window
                break;
            case 5:  
                RalphTopShow(1,0);        // show Ralph on top of the building left leg up
                PlaySound("ralphStamp_", vlm);    // sound for ralph stamping his feet
                WindowBreak(3);    // show the next broken window
                break;
            case 6: 
                RalphTopShow(0,1);        // show Ralph on top of the building right leg up
                PlaySound("ralphStamp_", vlm);    // sound for ralph stamping his feet
                WindowBreak(4);    // show the next broken window
                break;
            case 7: 
                 RalphTopShow(1,0);        // show Ralph on top of the building left leg up
                PlaySound("ralphStamp_", vlm);    // sound for ralph stamping his feet
                WindowBreak(5);    // show the next broken window
                break;
            case 8: 
                RalphTopShow(0,1);        // show Ralph on top of the building right leg up
                PlaySound("ralphStamp_", vlm);    // sound for ralph stamping his feet
                WindowBreak(6);    // show the next broken window
                break;
            case 9: 
                RalphTopShow(1,0);        // show Ralph on top of the building legs down
                PlaySound("ralphStamp_", vlm);    // sound for ralph stamping his feet
                WindowBreak(7);    // show the next broken window
                break;
            case 10: 
                RalphTopShow(0,1);        // show Ralph on top of the building right leg up
                PlaySound("ralphStamp_", vlm);    // sound for ralph stamping his feet
                WindowBreak(8);    // show the next broken window
                break;
            case 11: 
                RalphTopShow(1,0);        // show Ralph on top of the building left leg up
                PlaySound("ralphStamp_", vlm);    // sound for ralph stamping his feet
                WindowBreak(9);    // show the next broken window
                break;
            default: 
        };    
        ralphStartSequence++;    // next step
        if (ralphStartSequence<3) ralphMoveID = window.setTimeout("RalphStart()", 1000)    // start next sequence of ralph moving in a second
        if (ralphStartSequence<(brokenWindows+3)) ralphMoveID = window.setTimeout("RalphStart()", 500)    // start next sequence of ralph movling in half a second as long as not all broken windows are shown
        else {
            RalphTopShow(0,0);        // show Ralph on top of the building both legs down
            FelixShow();    // show felix @ current position
            GameGo();    // start the game
            bricksNextID = window.setTimeout("BricksNext()", (gameSpeed/2+10));    // determin and place to put 1 or 2 sets of bricks in half gameSpeed milliseconds;
            pause = false;    // no pause
        };
    };
};

// hide ralph on top of the building
function RalphTopHide () {
    PicShow("RalphTop", nullPre.src);    // to hide Ralph's torso on top of the building
    PicShow("RalphTopLeftLegDown", nullPre.src);    // to hide Ralph's left leg down on top of the building
    PicShow("RalphTopLeftLegUp", nullPre.src);// to hide Ralph's left leg up on top of the building
    PicShow("RalphTopRightLegDown", nullPre.src);    // to hide Ralph's right leg down on top of the building
    PicShow("RalphTopRightLegUp", nullPre.src);    // to hide Ralph's right leg up on top of the building
};

// show ralph on top of the building
function RalphTopShow (leftLeg,rightLeg) {
    PicShow("RalphTop", ralphTopPre.src);    // to show Ralph's torso on top of the building
    if (leftLeg) {
        PicShow("RalphTopLeftLegDown", nullPre.src)    // to hide Ralph's left leg down on top of the building
        PicShow("RalphTopLeftLegUp", ralphTopLeftLegUpPre.src);// to show Ralph's left leg up on top of the building
    } else {
        PicShow("RalphTopLeftLegDown", ralphTopLeftLegDownPre.src);    // to show Ralph's left leg down on top of the building
        PicShow("RalphTopLeftLegUp", nullPre.src);// to hide Ralph's left leg up on top of the building
    };
    if (rightLeg) {
        PicShow("RalphTopRightLegUp", ralphTopRightLegUpPre.src);    // to show Ralph's right leg up on top of the building
        PicShow("RalphTopRightLegDown", nullPre.src);    // to hide Ralph's right leg down on top of the building
    } else {
        PicShow("RalphTopRightLegDown", ralphTopRightLegDownPre.src);    // to show Ralph's right leg down on top of the building
        PicShow("RalphTopRightLegUp", nullPre.src);    // to hide Ralph's right leg up on top of the building
    };
};

// fix the broken windows
function WindowFix () {
    if (windowGlass[posy][posx]) {    // if window broken
        windowGlass[posy][posx]--;    // fix (part @ double) window
        if (!demo) {
            PlaySound("windowFix_", vlm);    // sound for fixing the window
            ScoreAdd(1);
            ScoreShow(score);
        };
    };
    // console.log("@WindowFix () : windowGlass = "+windowGlass);
    WindowsShow();
};

// check if all broken windows have been fixed
function WindowsFixed () {
    var windowsFixed = true;
    for (i=1 ; i<3 ; i++) {     // to check the windows on all floors
        for (j=1 ; j<5 ; j++) {     // to check the windows on each floor
                if (windowGlass[i][j]) windowsFixed = false;    // if broken window found
        };
    };
    return windowsFixed;
};

// show the next broken window & count all
function WindowBreak (num) {
    var windowUp = 0;    // no broken windows counted
    for (i=1 ; i<3 ; i++) {     // to count the windows on all floors
        for (j=1 ; j<5 ; j++) {     // to count the windows on each floor
            if (i==2&&j==2) { // (the two-pieced window)
                if (windowGlass[i][j]>0) {	// if double window up
                    windowUp++;	// count broken window
                    if (windowUp==num) PicShow("Window_"+eval(i)+"_"+eval(j)+"_"+eval(1), windowPre[i][j][1].src)	// show top broken window
                } else PicShow("Window_"+eval(i)+"_"+eval(j)+"_"+eval(1), nullPre.src);	// hide window
                if (windowGlass[i][j]>1) {	// if double window up with 2
                    windowUp++;	// count broken window
                    if (windowUp==num) PicShow("Window_"+eval(i)+"_"+eval(j)+"_2", windowPre[i][j][2].src)	// show bottom broken window
                } else PicShow("Window_"+eval(i)+"_"+eval(j)+"_2", nullPre.src);	// hide window
            } else { // all single-pieced windows
                if (windowGlass[i][j]) {	// if single window up
                    windowUp++;	// count broken window
                    if (windowUp==num) PicShow("Window_"+eval(i)+"_"+eval(j), windowPre[i][j].src)	// show broken window
                } else PicShow("Window_"+eval(i)+"_"+eval(j), nullPre.src);	// hide broken window
            };
        };
    };
    return windowUp;        // return counted windows
};

//--------------------------------------------------------------------

// choose number of broken windows
function WindowsChoose (num) {
    var windowx;    // horizontal position of chosen window
    var windowy;    // vertical position of chosen window
    for (i=1 ; i<(9-num) ; i++) {
        do {        // set chosen number of windows
            windowx = Math.floor(4*Math.random())+1;
            windowy = Math.floor(2*Math.random())+1;
         } while (!windowGlass[windowy][windowx]);    // as long as window already taken
        windowGlass[windowy][windowx] = 0;    // 
    };
};

// unset all present windows (fix them all)
function WindowsClear () {
    for (i=1 ; i<3 ; i++) {     // to set the windows on all floors
        for (j=1 ; j<5 ; j++) {     // to set the windows on each floor
            windowGlass[i][j] = 0;
        };
    };
};

// hide all broken windows
function WindowsHide () {
    for (i=1 ; i<3 ; i++) {     // to hide the windows on all floors
        for (j=1 ; j<5 ; j++) {     // to hide the windows on each floor
            if (i==2&&j==2) {  // hide the two-pieced window
                PicShow("Window_"+eval(i)+"_"+eval(j)+"_"+eval(1), nullPre.src);
                PicShow("Window_"+eval(i)+"_"+eval(j)+"_2", nullPre.src);
            } else  // hide all single-pieced windows
                PicShow("Window_"+eval(i)+"_"+eval(j), nullPre.src);
        };
    };
};

// set all present windows (break them all)
function WindowsReset () {
    for (i=1 ; i<3 ; i++) {     // to set the windows on all floors
        for (j=1 ; j<5 ; j++) {     // to set the windows on each floor
            if (i==2&&j==2) windowGlass[i][j] = 2    // double window to break and fix
            else windowGlass[i][j] = 1;
        };
    };
};

// set the broken windows
function WindowsSet () {
    WindowsReset();    // break them all
    switch (true) {
        case ((score%100)>70): // all windows put in place
            break;
        case ((score%100)>50): 
            WindowsChoose (7)    // put 7 windows in a random place (delete 1)
            break;
        case ((score%100)>30): 
            WindowsChoose (6)    // put 6 windows in a random place (delete 2)
            break;
        case ((score%100)>10): 
            WindowsChoose (5)    // put 5 windows in a random place (delete 3)
            break;
        case ((score%100)>-1): 
            WindowsChoose (4)    // put 4 windows in a random place (delete 4)
            break;
        default: 
    };
}; 

// show the broken windows
function WindowsShow () {
    for (i=1 ; i<3 ; i++) {     // to show the windows on all floors
        for (j=1 ; j<5 ; j++) {     // to show the windows on each floor
            if (i==2&&j==2) { // (the two-pieced window)
                if (windowGlass[i][j]>0) PicShow("Window_"+eval(i)+"_"+eval(j)+"_"+eval(1), windowPre[i][j][1].src)    // show broken window if set on this place
                else PicShow("Window_"+eval(i)+"_"+eval(j)+"_"+eval(1), nullPre.src);    // hide broken window if not set on this place
                if (windowGlass[i][j]>1) PicShow("Window_"+eval(i)+"_"+eval(j)+"_2", windowPre[i][j][2].src)    // show broken window if 2 set on this place
                else PicShow("Window_"+eval(i)+"_"+eval(j)+"_2", nullPre.src);    // hide broken window if not set on this place
            } else { // all single-pieced windows
                if (windowGlass[i][j]) PicShow("Window_"+eval(i)+"_"+eval(j), windowPre[i][j].src)    // show broken window if set on this place
                else PicShow("Window_"+eval(i)+"_"+eval(j), nullPre.src);    // hide broken window if not set on this place
            };
        };
    };
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end preload screen figures & show/hide all of them

//set/reset functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// stop game if playing and reset all ID's
function AllStop () {
    GameReset();    // clear all game delay parameter ID's
    pause = true;    // pause game
    pointsBonus = false;    // no bonuspoints
    TimerReset(); // stop the counter to show the current time
};

// clear all game delay parameter ID's
function GameReset () {
    if (blinkID) {    // ID for timeout blinking score)
        window.clearTimeout(blinkID);    // reset ID for hiting hand delay
        blinkID = null;
    };
    if (bricksNextID) { 
        window.clearTimeout(bricksNextID);    // reset ID for setting new bricks
        bricksNextID = null;
    };
    if (bricksHurtID) {
        window.clearTimeout(bricksHurtID);    // reset ID for indicating the falling bricks are @ hurt level
        bricksHurtID = null;
    };
    if (demoID) {
        window.clearTimeout(demoID);    // stop demo from starting (again)
        demoID = null;
    };
    if (felixBlinkID) {
        clearTimeout(felixBlinkID);    // stop felix blinking
        felixBlinkID = null;
    };
    if (gameID) {
        clearTimeout(gameID);    // stop the game
        gameID = null;
    };
    if (missedID) {
        window.clearTimeout(missedID);    // stop miss sequence
        missedID = null;
    };
    if (pauseID) {
        clearTimeout(pauseID);  // stop pause manipulation
        pauseID = null;
    };
    if (ralphBricksID) {
        window.clearTimeout(ralphBricksID);    // reset ID for ralph dropping bricks
        ralphBricksdID = null;
    };
    if (ralphFallID) {
        window.clearTimeout(ralphFallID);    // reset ID for falling ralph
        ralphFallID = null;
    };
    if (ralphMoveID) {
        window.clearTimeout(ralphMoveID);    // reset ID for moving ralph @ level start
        ralphMoveID = null;
    };
    if (scoreBonusID) {
        window.clearTimeout(scoreBonusID);    //  stop beeping @ bonus indication
        scoreBonusID = null;
    };
};

// reset all parameters for the next level
function LevelReset () {
    missed = false;    // missed sequence is over
    sequence = 1;       // game sequence reset
    ralphFallSequence = 1;       // ralph falling sequence reset
    ralphStartSequence = 1;       // game ralph starting sequence reset
    PanelsSet();    // set panels according to score
    posx = 1;    // horizontal startposition
    posy = 1;    // vertical startposition
    MainPicturesGame();    // show default pictures @ start of the game
};

// Let the misses blink & reset them
function MissReset () {
    if (missedID) {
        window.clearTimeout(missedID);    // prepare for delayed missclear 
        missedID = null;
    };
    if (game==1) {
        MissBlink();    // let misses blink if score over 300 or 500 and misses will be reset
        missClearID = window.setTimeout("MissClear()", 2000);    // remove "MISS" text & reset lives & misses after 2 seconds
    } else MissClear(); // remove "MISS" text & reset lives & misses
};

// clear all pictures & variables
function ResetAll () {
    AllStop();  // stop game if playing and reset all ID's
    MissClear(); // remove "MISS" text & reset lives & misses
    AllPicturesClear ();        // hide all figures
//    alarmSet = "h";     // setting alarm hours (h) or minutes (m) @ NO cursor +
    alarmSet = "m";     // setting alarm hours (h) or minutes (m) @ cursor +
    alarmSetting = false;       // stop running alarm
    game = 0;   // no-game-all-pictures
    life = 0;    // no lives
    pause = false;    // no pause
    sequence = 0;       // game sequence reset
    ralphFallSequence = 1;       // ralph falling sequence reset
    ralphStartSequence = 1;       // game ralph starting sequence reset
};

// reset speed according to the current score
function SpeedReset () {
    gameSpeed = gameSpeedMin - Math.round(score%1000/25) - Math.floor(score/50) - Math.floor(score/1000);
    gameSpeed = gameSpeed>gameSpeedMax?gameSpeed:gameSpeedMax;
};

// stop showing current time
function TimerReset () {
    if (timeID) {
        clearTimeout(timeID);
        timeID = null;
    };
};

// "ACL" is pressed to clear all and reset all on going to default and show all figures
function TotalReset () {
    PlaySound("click_", vlm);    // click sound for push button
    if (alarm) TimeAlarmOff();    // stop alarm if running
    AlarmReset();    // set alarm to default settings
    ResetAll(); // clear all pictures & variables
    if (acl) AllPicturesShow()    // show all figures & "88:88" if "acl" clicked twice fast
    else MainPicturesShow(); // show all figures & "12:00"
    acl = true; // indicates "acl" already clicked
    if (alarmID) {
        alarmID = null;
        clearTimeout(alarmID);    // stop running alarm sound from repeating
    };
    if (alarmOffID) {
        alarmOffID = null;
        clearTimeout(alarmOffID);    // stop running timer to turn off alarm @ running
    };
    aclID = window.setTimeout("acl = false;", 130);     // to show all pictures if "acl" clicked twice in 130 milliseconds
    demoID = window.setTimeout("MainTimeStart()", 60000);    // start demo after a minute  
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end set/reset functions

//game functions																																																																																																																																																																																																																																																																																																																					
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// show demo
function Demo () {
    if (demoID) {    // if demo still planned to start stop that plan to avoid double run
        clearTimeout(demoID);
        demoID = null;
    };
    if (sequence<14) sequence++       // next sequence of the demo
    else sequence = 1;  // or first if demo sequence finished
    switch (sequence) {
        case 1: // first moment
            PicShow("PeopleTop", nullPre.src);        // hide the people on top of the building
            PicShow("FelixTop", nullPre.src);        // hide Felix on top of the building
            MainPicturesDefault();    // set & show broken wIndows
            PicShow("InvincibilityPie1", invincibilityPie1Pre.src);    // show invincibility pie on first floor @ 4th window
            bricks[2][1] = 1;    // show top bricks @ 1st window
            BricksShow();    // show the present bricks
            break;
       case 2:
            RalphTopShow(1,1);        // show Ralph on top both legs up
            GoRight();    // let felix go right
            BricksDrop();      // let the bricks fall
            break;
        case 3: 
            WindowFix();    // fix the second window on the first floor
            GoRight();    // let felix go right
            BricksDrop();      // let the bricks fall
            RalphTopShow(0,0);        // show Ralph on top legs down
            bricks[2][3] = 1;    // show top bricks @ 3rd window
            BricksShow();    // show the present bricks
            break;
        case 4:
            GoRight();    // let felix go right
            BricksDrop();      // let the bricks fall
            RalphTopShow(1,1);        // show Ralph on top both legs up
            break;
        case 5: 
            PicShow("InvincibilityPie1", nullPre.src);        // eat invincibility pie on first floor @ 4th window
            WindowFix(); // fix the fourth window on the first floor
            GoUp();    // let felix go up
            BricksDrop();      // let the bricks fall
            RalphTopShow(1,0);        // show Ralph on top left leg up
            break;
        case 6:
            GoLeft();    // let felix go left
            BricksDrop();      // let the bricks fall
            RalphTopShow(0,1);        // show Ralph on top right leg up
            bricks[2][4] = 1;    // show top bricks @ 4th window
            BricksShow();    // show the present bricks
            break;
        case 7:
            WindowFix();    // fix the third window on the second floor
            GoLeft();    // let felix go left
            BricksDrop();      // let the bricks fall
            RalphTopShow(1,0);        // show Ralph on top left leg up
            break;
        case 8:
            GoLeft();    // let felix go left
            BricksDrop();      // let the bricks fall
            RalphTopShow(0,1);        // show Ralph on top right leg up
            break;
        case 9:
            WindowFix();    // fix the tfirst window on the second floor
            GoUp();    // let felix go up
            BricksDrop();      // let the bricks fall
            RalphTopShow(0,0);   // show Ralph on top legs down
            break;
        case 10: 
            RalphTopHide();        // hide Ralph on top of the building
            PicShow("PeopleTop", peopleTopPre.src);        // show the people on top of the building
            PicShow("RalphDown", ralphDownPre.src);    // show Ralph falling down the building
            break;
        case 11: 
            PicShow("RalphDown", nullPre.src);    // hide Ralph falling down the building
            PicShow("Impact1", impact1Pre.src);    // show impact 1 when Ralph fell down the building
            break;
        case 12: 
            PicShow("Impact2", impact2Pre.src);    // show impact 2 when Ralph fell down the building                        
            break;
        case 13: 
            PicShow("Impact2", nullPre.src);    // hide impact 2 when Ralph fell down the building                        
            break;
        case 14: 
            PicShow("Impact1",nullPre.src);    // hide impact 1 when Ralph fell down the building
            break;
        default: 
    };
    demoID = window.setTimeout("Demo()", 1000);    // next step after a second  
};

// let felix blink while felix is invincible or hit
function FelixBlink () {    
    if (felixBlinkID) {
        window.clearTimeout(felixBlinkID);    // prepare for next blink
        felixBlinkID = null;
    };
    if (game==1&&posy<3) {    // game running & felix not yet on top of the building
        if (felixBlink<6) {    // number of blinking felix
            FelixHide(); // hide Felix @ any position on the building
            felixBlinkID = window.setTimeout("FelixShow()", blinkSpeed/2); // show felix
            felixBlinkID = window.setTimeout("FelixBlink()", blinkSpeed);    // repeat
        } else {
            if (invincibility) {
                invincibility = 0; // felix is no longer temporarily invincible
                PlaySound("invincibleDone_",vlm);    //play sound of invincibility over
            } ;
        } ;
    felixBlink++;      // count blinking
    } else invincibility = 0; // felix is no longer temporarily invincible
};

// next move of game
function GameGo () {
    if (bricksNextID) { 
        window.clearTimeout(bricksNextID);    // prepare for dropping bricks
        bricksNextID = null;
    };
    if (gameID) {
        clearTimeout(gameID);    // stop the game's possible double call
        gameID = null;
    };
    if (!pause&&!gameOver) {
        BricksDrop()
        bricksNextID = window.setTimeout("BricksNext()", (gameSpeed/2+10));    // determin and place 1 or 2 sets of bricks in half gameSpeed milliseconds;
    }; 
    gameID = window.setTimeout("GameGo()", gameSpeed);    // next step in gameSpeed milliseconds
};

// resume game after pause for indicating miss or end level
function GameGoNext () {
    if (game==1) {     // if game a or b running
        if (gameID) {
            clearTimeout(gameID);    // reset ID for next step to prevent double call
            gameID = null;
        };
        if (life>0) {   // if at least one life left
            LevelReset();    // reset all parameters for the next level 
            brokenWindows = WindowBreak(0);    // count the broken windows for ralph to break
            RalphStart();    // ralph starts every level of the game by wrecking windows
        } else demoID = window.setTimeout("MainTimeStart()", 60000);    // start demo after a minute  
    };
};

// common settings games
function GameSet () {
    ResetAll();    // clear all pictures & variables
    MissClear(); // remove "MISS" text & reset lives & misses
    score = 0;  // reset current score
    LevelReset();    // reset all parameters for the next level
    MainPicturesGame();    // show default pictures @ start of the game
    PanelsSet();    // set panels according to score
};

// button pressed to play the game
function MainGameA () {
    if (alarm) TimeAlarmOff();    // stop alarm if running
    if (game!=1) {   // if not already game playing
        if (demo) {
            demo = false;        // once this key is hit, the demo is turned off
            if (demoID) {
                clearTimeout(demoID);   // prevent demo from restarting if planned
                demoID = null;
            };
        };
        GameSet(); // set game variables
        gameSpeed = 1000;       // istarting gamespeed in milliseconds
        gameSpeedMax = 500;    // maximum speed for game sequence timer
        ShowSndIcns();      // show/hide icon for alarm as set
        HighScoreShow(1);        // show highest score since this browser tab was opened
    };
};

// "GAME" button released so actually play the game
function MainGameAGo () {
    if (game!=1) {   // if not already game playing
        if (gameID) {
            clearTimeout(gameID);    // stop the game's possible double call
            gameID = null;
        };
        game = 1; // game A
        pause = true;    // pause game till ralph has done wrecking
        ScoreShow(score);
        brokenWindows = WindowBreak(0);    // count the broken windows for ralph to break
        RalphStart();    // ralph starts every level of the game by wrecking windows
    };
};

// game is over, 3 misses, you lost
function MainGameOver () {
    if (demoID) {
        clearTimeout(demoID);    // prepare for demo
        demoID = null;
    };
    AllStop();  // stop game if playing and reset all ID's
    missedID = window.setTimeout('game = 3;',(blinkSpeed*5));    // delayed game over indication so next game can't start too soon
    PlaySound("gameOver_", vlm);    // game over sound
    demoID = window.setTimeout("MainTimeStart()", 60000);    // start demo after a minute  
};

// let misses blink if score over 300 or 500 and misses will be reset
function MissBlink () {    
    if (missedID) {
        window.clearTimeout(missedID);    // rest miss cycle
        missedID = null;
    };
    if (game==1) {    // game running
        if (missedBlink<4) {    // number of blinking the misses
            MissHide(); // hide misses 
            Beep();
            missedID = window.setTimeout("MissedShow()", blinkSpeed/2); // show delayed all misses  & miss text
            missedID = window.setTimeout("MissBlink()", blinkSpeed);    // repeat
        } else {
            MissHide(); // hide misses 
            Beep();
        };
    missedBlink++;      // count blinking
    };
};

// remove "MISS" text & reset lives & misses
function MissClear () {
    MissTextHide ();    // remove "MISS" text
    life = 3;	// all lives 
    missed = false;	// miss reset
};

// process miss variables and continue 
function Missed () {
    if (game==1&&!missed) {    // if game playing and the miss not already detected
        missed = true;    // miss detected
        pause = true;    // game paused
        if (missedID) {
            clearTimeout(missedID);    // to delay game a bit after miss
            missedID = null;
        };
        invincibility = 0;    // no longer invincible if  active
        life--;    // a life is lost
        felixBlink = 0;        // start of felixblink
        FelixBlink();	// let felix blink to indicate hit
        pointsBonus = false;     // no more bonuspoints if earned
        MissedShow();    // show misses & txt if present 
        if (life>0) {    // if still a life left
            missedID = window.setTimeout("GameGoNext()", (blinkSpeed*7))    // next step after a couple of seconds
        } else {
             missedID = window.setTimeout("MainGameOver();", (blinkSpeed*7))     // game is over, 3 misses, you lost
        };
    };
};

// show leading zeroes
function n(n){
    return n>9?""+n:"0"+n;
};

// speeds up the game with given value
function SpeedUp (speed) {
    var prevSpeed = gameSpeed;  // for logging...
    if (gameSpeed>gameSpeedMax) gameSpeed -= speed; // if not @ max speed, speed up
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end game functions

