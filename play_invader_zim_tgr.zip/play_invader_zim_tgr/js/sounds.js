/*------------------------------------------------------------------sound------------------------------------------------------------------*/

var prefSoundShow = 0;
var soundEnded = true;	// no sound playing
var soundEndedID;	// little delay to avoid wrong sound @ simultaneous hit by odd numbers

function PlaySoundAlways (name, vol) {
	var playPromise;	// play-preset indicator
	name+="wav";
	playPromise = document.getElementById(name).play();
	if (vol) { 
		document.getElementById(name).volume = vol;
	}
	if (playPromise !== undefined) {
		playPromise.then(_ => {
			// playback started!
		})
		.catch(error => {
			// play was prevented
		});
	}
}

function PlaySound (name, vol) {
	if ( prefSound&&!demo ) {
		PlaySoundAlways (name, vol);
	}
}

function PlaySoundEvenIfDemo (name, vol){
	if ( prefSound ) {
		PlaySoundAlways (name, vol);
	}
}

// Show sound settings according to current settings
function PrefSoundEval () {
	if (!prefSound) { // if sound is set to "off" 
		StopAllSound();
		preVlm = vlm;   // remember last sound volume
		vlm = 0;		// set volume to 0
	} else {
		if (preVlm==0) preVlm = 0.01; // if no previous volume, set to minimum
		vlm = preVlm;   // set volume to "on"
	};
	PrefSoundShow();	// show volume indicator on screen for testing purposes
};

// swich sound on/off; dont preload here
function PrefSound () {
	prefSound = !prefSound;
	PrefSoundEval();	// Show sound settings according to current settings
};

// show/hide volume indicator for testing purposes
function PrefSoundShow () {
	var vlmTxt = "";	// empty sound volume indicator picture
	$("#SoundStateInd").html("");	// empty/hide volume indicator
	if (prefSoundShow) {	  // if volume indicator is set to show
		$("#SoundStateIndBkgnd").removeClass("hidden");		
		if (vlm>0.00999) {
			for(var i=1; i<=(vlm*100); i++) vlmTxt += '<img SRC="img/screen/volume/SoundStateInd.png" name="SoundStateInd" border=0 style="float:left">';
			$("#SoundStateInd").html(vlmTxt);	// show counted number of sound indicator bars
		} else $("#SoundStateInd").html('<img SRC="img/null.gif" name="SoundStateInd" border=0>');	// hide volume indicator
	} else {
		$("#SoundStateIndBkgnd").addClass("hidden");
		$("#SoundStateInd").html('<img SRC="img/null.gif" name="SoundStateInd" border=0>');	// hide volume indicator
	};
};

// swich sound on/off; dont preload here
function SetSound (setting) {
	prefSound = setting;
};

// stop all playing sounds
function SetSoundVolume () {
	document.getElementById("hit1_wav").volume = vlm;
	document.getElementById("hit2_wav").volume = vlm;
	document.getElementById("hit3_wav").volume = vlm;
	document.getElementById("hit4_wav").volume = vlm;
	document.getElementById("hit5_wav").volume = vlm;
	document.getElementById("gameover_wav").volume = vlm;
	document.getElementById("miss_wav").volume = vlm;
};

// stop all playing sounds
function StopAllSound () {
	soundEnded = true;	// to end waiting for end of sound loop
	StopSound("gameover_", vlm);
	StopSound("miss_", vlm);
	StopAllHitSound();
};

// stop all playing hit sounds
function StopAllHitSound () {
	StopSound("hit1_", vlm);
	StopSound("hit2_", vlm);
	StopSound("hit3_", vlm);
	StopSound("hit4_", vlm);
	StopSound("hit5_", vlm);
};

function StopSound (name, vol){
	var playPromise;	// play-preset indicator
	name+="wav";
	playPromise = document.getElementById(name).pause();
	if (vol) { 
		document.getElementById(name).volume = vol;
	}
	if (playPromise !== undefined) {
		playPromise.then(_ => {
			// playback stopped!
		})
		.catch(error => {
			// stopping was prevented
		});
	}
}

//
function SoundEnded (soundName) {
	if (soundEndedID) {
		window.clearTimeout(soundEndedID);	// stop computer from making move 
		soundEndedID = null;
	};
	// with little delay to avoid wrong sound @ simultaneous hit by odd numbers
	soundEndedID  = window.setTimeout("soundEnded = true;", 1);	// end of current sound playing
};

/*------------------------------------------------------------------sound------------------------------------------------------------------*/
