//Product:	        Invader Zim HTML - Tiger handheld Simulator
//Version:	        1.1
//Started:	        11.09.2024
//Last update:	        11.11.2024
//Author/creator:      MariiBoops : https://www.deviantart.com/mariiboops
//Programmer	        Flyzy (Joeri Thys) : https://flyzy67.itch.io
//Original gif:	           MariiBoops : https://www.deviantart.com/mariiboops/art/Invader-Zim-The-Cheap-LCD-Game-835180334


//initialise variables
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var demo = false;       // indicates if demo is running or not
var demoID;     // ID for timeout demo autostart after last handling 

var game = 0;   // 0-no-game-acl-pictures; 1-game; 3-game-over; 4-clock; 
var gameID;	// ID for timeout game sequence
var gameOver; // game over animation running
var gameSpeedMinimum = 350;	// minimum speed for game sequence timer
var gameSpeedMaximum = 150;	// maximum speed for game sequence timer
var gameSpeed = 500;	// speed for game sequence timer
var hitSequence = new Array();  // array of all people's hit indication and animation
var life = 3;   // number of lives left
var mainPicturesGameSetup = 0;	// to prevent unwanted added people during game setup
var missedID;   //      ID for missed animation
var missed = false;     // indicating miss occured and game stopped
var missile = new Array();	// qll missile places
var missedPos;  // position missed People to jump up to victory
var missileDown = new Array();	// missile ended its traject @ row
var nomove;	// no move possible during game intro
var peopleHitID = new Array();	// for hitind movement when people are hit
var peopleHit = false;    // indicates if a surfaced People is hit
var peoplePresent = new Array();  // array of all people positions
var highScore = 0;
var peopleOutRow = 0;	// row where people reached top
var pause = false;		// game not paused
var pos;        // position zim
var sequence = 1;		// sequence for demo, game intro, miss & game over animation
var shootID;      // for shooting movement
var zoomed = 1;		// default screen auto adapted to window size

// reset pressed keys to none pressed
var OnKeyPressed = false;	// indicates if a previuos hit "of the game A" key was already pressed to avoid double entries
var keyPressed = false; // indicates if a previuos direction key was already pressed to avoid double entries
var shootKeyPressed = false;	// indicates if a previuos hit key was already pressed to avoid double entries
var PauseKeyPressed = false;	// indicates if a previuos hit "ACL" key was already pressed to avoid double entries
var TKeyPressed = false;	// indicates if a previuos hit "TIME" key was already pressed to avoid double entries

var prefSound = 1;      // 1-on; 0-off

var score = 0;	// score (all beneath 100) at init

var timeID;     // ID for timeout time indication @ demo
var today = new Date();
var hour = today.getHours();
var min = today.getMinutes();
var sec = today.getSeconds();
var expiry = new Date(today.getTime() + 28 * 24 * 60 * 60 * 1000);	// 28 days for cookie to expire

var vlm = 1;            // sound volume 0.01-1
var preVlm = vlm;       // previous sound volume 0.01-1 to set when sound turned on again
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end initialise variables

//read pushed buttons & act accordingly
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
window.addEventListener("keydown", function (e) {
    codeCurrent = e.keyCode;		// for reading game keys
    e.preventDefault();		// prevent some browsers to shift, scroll, go page back or do other stuff when key pressed
    switch (e.key) {
        case "q": case "Q": case "ArrowLeft":	// left keys
            // show control button left pressed
            document.images['CurControl'].src = 'img/case/buttons/controlleft.png';     
            LeftPressed();      // function to move left
            break;
        case "s": case "S": case "ArrowRight":	// right keys
            // show control button right pressed
            document.images['CurControl'].src = 'img/case/buttons/controlright.png';     
            RightPressed();     // function to move right
            break;
        case "Space": case " ":	// space key
            // show shoot button pressed
            document.images['CurShoot'].src = 'img/case/buttons/shoot_flat.png';     
            ShootPressed();     // function to shoot @ current position
            break;
        case "1": case"a": case"A":     // if "1", "a" or "A" pressed
            // show on button pressed
            document.images['ButOn'].src = 'img/case/buttons/buton_flat.png';     
            if (!OnKeyPressed&&!PauseKeyPressed&&!TKeyPressed) {
                OnKeyPressed = true;
                MainGameA(); // show high score @ play Game after button release
            };
            break;
        case"n": case"N":     // if "n" or "N" pressed
            // show acl button pressed
            document.images['ButSound'].src = 'img/case/buttons/butsound_flat.png';
            if (!keyPressed&&!PauseKeyPressed&&!TKeyPressed) {
                PauseKeyPressed = true;
                PrefSound(); // set sound on/off
            };
            break;
        case"p": case"P":     // if "p" or "P" pressed
            // show pause button pressed
            document.images['ButPause'].src = 'img/case/buttons/butpause_flat.png';
            Pause(); // set/unset game pause
            break;
        case"t": case"T":     // if "t" or "T" pressed
            // show off button pressed
            document.images['ButOff'].src = 'img/case/buttons/butoff_flat.png';
            if (!OnKeyPressed&&!keyPressed&&!TKeyPressed) {
                TKeyPressed = false;
                MainTime(); // show time & demo
            };
            break;
        //test case buttons 
        case "+":	// "+"-numpadkey
            if (vlm<1) {
                vlm = (parseFloat(vlm) + 0.01).toFixed(2);	// increase volume for test purposes
                preVlm = vlm;   // current volume becomes previous set @ next change of volume
            };
            if (vlm==0.01)  SetSound(true);	// show sound turned on
            PrefSoundShow();	// show volume indicator on screen for testing purposes
            break;
        case "-":	// "-"-key
            if (vlm>0) {
                vlm = (parseFloat(vlm) - 0.01).toFixed(2);	// decrease volume for test purposes
                preVlm = vlm;   // current volume becomes previous set @ next change of volume
            };
            if (vlm==0) SetSound(false);	// show sound turned off
            PrefSoundShow();	// show volume indicator on screen for testing purposes
            break;
        case "/":    // "/"-key
            if (vlm==0.3) vlm = 0.03
            else vlm = 0.3;
            PrefSoundShow();    // show volume indicator on screen for testing purposes
            break;
        case "@": case String.fromCharCode(233):	// mac-"@"(at)-key/win-"é"(e-accent-egue)-key 
            prefSoundShow = !prefSoundShow;     // show/hide indicator
            PrefSoundShow();	// show volume indicator on screen for testing purposes
            break;
        case ")": case String.fromCharCode(219):
            zoomed = zoomed?0:1;
            $(function () {
                CheckSizeZoom();
                $('#divWrap').css('visibility', 'visible');
            });
            $(window).resize(CheckSizeZoom);
            break;
        case"r": case"R":     // if "r" or "R" pressed
            game = 0;
			    ResetAll();
    			if (demoID) {	// if demo still planned to start stop that plan to avoid double run
        			clearTimeout(demoID);
        			demoID = null;
			    };
            // show all pics
            AllPicturesShow();		// show all figures on screen
   			 demoID = window.setTimeout("MainTimeStart()", 60000);	// start demo after a minute  
            break;
        default:
    };
    console.log(" - You pressed e.keyCode   : \x1B[35m" + e.keyCode + "\x1B[30m <==> '" + e.key + "'          pause = "+pause+ "         missed = "+missed+ "          game = "+game+" - keyPressed = "+ keyPressed+" - PauseKeyPressed = "+PauseKeyPressed+" - TKeyPressed = "+TKeyPressed+" - shootKeyPressed = "+shootKeyPressed+ " \x1B[35mgameSpeed  = "+gameSpeed);
}, false);

window.addEventListener("keyup", function (e) {
    // game and arrow keys
    switch (e.key) {
        case "q": case "Q": case "ArrowLeft":	// left key released
            // show control button default
            document.images['CurControl'].src = 'img/case/buttons/control.png';     
            keyPressed = false;
            break;
        case "s": case "S": case "ArrowRight":	// right key released
            // show control button default
            document.images['CurControl'].src = 'img/case/buttons/control.png';     
            keyPressed = false;
            break;
        case "Space": case " ":	// space key released
            // show shoot button default
            document.images['CurShoot'].src = 'img/case/buttons/shoot.png'; 
            shootKeyPressed = false;    
            break;
        case "1": case"a": case"A":     // if "1", "a" or "A" released
				document.images['ButOn'].src = 'img/case/buttons/buton.png';
   				if (OnKeyPressed) MainGameAGo(); // start running Game 
            OnKeyPressed = false;
            break;
        case"n": case"N":     // if "s" or "S" pressed
            document.images['ButSound'].src = 'img/case/buttons/butsound.png';
            PauseKeyPressed = false;
            break;
        case"p": case"P":     // if "w" or "W" pressed
            document.images['ButPause'].src = 'img/case/buttons/butpause.png';
            break;
        case "t": case"T":     // if "t" or "T" released
            document.images['ButOff'].src = 'img/case/buttons/butoff.png';
            break;
        default: 
    };
    // console.log("@ "+hour+":"+(min<10?("0"+min):min)+":"+(sec<10?("0"+sec):sec)+"    ---     : demoID = "+demoID+"---   - @keyup   ");
}, false);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end read pushed buttons & act accordingly

// if reviewing this tab, refresh screen if necessary
$(window).focus(function(){
    //focus log code
    console.log("@ "+hour+":"+(min<10?("0"+min):min)+":"+(sec<10?("0"+sec):sec)+"    ---     : demoID = "+demoID+"---  "+"  ---      %c Window focused ! %c   ...   %c Refreching screen ... %c   --   %c Welcome back! %c          ---          "+(gameOver?"screen not refreshed because GAME OVER !!!%c%c":"%c SCREEN REFRESHED ! %c"),
                "background-color:red; color:white; font-weight:bold;",
                "background-color:none; color:black; font-weight:bold;",
                "background-color:turquoise; color:blue; font-weight:bold;",
                "background-color:none; color:black; font-weight:bold;",
                "background-color:green; color:white; font-weight:bold;",
                "background-color:none; color:black; font-weight:bold;",
                "background-color:purple; color:white; font-weight:bold;",
                "background-color:none; color:black; font-weight:bold;",
                "     ---");     // color test
	$("#game").focus(); // get focus on the game
});

//when page loaded focus on game 
$(document).ready(function () {
	console.log('\x1B[31mHello\x1B[34m World   \x1B[30m30 \x1B[31m31 \x1B[32m32 \x1B[33m33 \x1B[34m34 \x1B[35m35 \x1B[36m36 \x1B[37m37 \x1B[38m38 \x1B[39m39'); 	// color test
    $(function () {
        CheckSizeZoom();	// zoom according to window size
    });
    $(window).resize(CheckSizeZoom);
    $("#game").focus(); // get focus on the game
    PicPreload();	// this function preloads all scream images to make them ready for use
    AllPicturesShow();			// show all figures on screen
   demoID = window.setTimeout("MainTimeStart()", 60000);	// start demo after a minute  
});

//standard functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// actually go to the left
function GoLeft () {
    if (pos>1) {	// if not totally left
        missileDown[pos] = true;	// missile ended its traject
        pos--;	// go position to the left with zim
        ZimShow(pos);		// show zim @ his current position
    };
};

// actually go to the right
function GoRight () {
    if (pos<5) {	// if not totally right
        missileDown[pos] = true;	// missile ended its traject
        pos++;	// go position to the right with zim
        ZimShow(pos);		// show zim @ his current position
    };
};

// hit button or -key pressed
function ShootPressed () {
    if (!shootKeyPressed&&!demoID&&life>0&&!pause&&missileDown[pos]&&!missed&&!nomove) {        // to avoid continious hit @ running game
        missileDown[pos] = false;		// missile traject not ended
        shootKeyPressed = true;
        Shoot(pos);    // shoot missile @ this position
    };
};

// left button or -key pressed
function LeftPressed () {
    if (!keyPressed&&game==1&&!demoID&&!pause&&!missed&&!nomove) {	// if game playing
        GoLeft();	// go position to the left with zim
        keyPressed = true;
    };
};

// make an array
function MakeArray (size) {
    this.length = size;
    for(var i=1; i<=size; i++) this[i] = 0;
};

// show/hide figure on screen
function PicShow (id, name) {
    if (name) document.images[id].src = name;	// if picture given assign it to the figure
};

// right button or -key pressed
function RightPressed () {
    if (!keyPressed&&game==1&&!demoID&&!pause&&!missed&&!nomove) {	// if game playing
        GoRight ();	// go position to the right with zim
        keyPressed = true;
    };
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end standard functions

//preload screen figures & show/hide all of them
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// this function preloads all images
function PicPreload () {
    gameOverPre = new Image();
    gameOverPre.src = "img/screen/gameover_full.png";	// full game over figure
    gameOverDownPre = new Image();
    gameOverDownPre.src = "img/screen/gameover_down.png";	// game over figure buzzed down
    gameOverUpPre = new Image();
    gameOverUpPre.src = "img/screen/gameover_up.png";	// game over figure buzzed up
    hitIndPre = new Array();
    for (i=1 ; i<5 ; i++) { 	// to show the 5 sets of people hitindications
        hitIndPre[i] = new Image();
        hitIndPre[i].src = "img/screen/hitind"+eval(i)+".png";    // People hit by missile
    };
    lifePre = new Array();
    for (i=1 ; i<4 ; i++) lifePre[i] = new Image();
    for (i=1 ; i<4 ; i++) lifePre[i].src = "img/screen/life"+eval(i)+".png";		// to show lives left
    nullPre = new Image();
    nullPre.src = "img/null.gif";	// empty picture to hide any figure
    numPre = new Array();
    for (i=1 ; i<11 ; i++) { 	// to show the 10 numbers
        numPre[i] = new Image();
        numPre[i].src = "img/screen/num"+eval(i-1)+".png";
    };
    numColonPre = new Image();
    numColonPre.src = "img/screen/num_colon.png";	// to show time splitter colon
    missilePre = new Array();
    for (i=1 ; i<4 ; i++) { 	// to show the 3 different missiles
        missilePre[i] = new Image();
        missilePre[i].src = "img/screen/missile"+eval(i)+".png";    // missiles
    };
    peoplePre = new Array();
    for (i=1 ; i<5 ; i++) { 	// the rows
        peoplePre[i] = new Array();
        for (j=1 ; j<6 ; j++) { 	// the lines
            peoplePre[(i*10+j)] = new Image();
            peoplePre[(i*10+j)].src = "img/screen/people"+eval(i)+eval(j)+".png";    // emerging People
        };
    };
    zimPre = new Array();
    for (i=1 ; i<6 ; i++) zimPre[i] = new Image();	// 5 possible positions
    for (i=1 ; i<6 ; i++) zimPre[i].src = "img/screen/zim"+eval(i)+".png";		// to show zim @ his position
};

// hide all  hit Indications
function AllHitIndHide () {
    for (x=1 ; x<5 ; x++) { 	      // the rows
        for (y=1 ; y<6 ; y++) { 	// the lines
            PicShow("HitInd"+eval(x)+eval(y)+"", nullPre.src);
        };
    };
};

// show all  HitIndications
function AllHitIndShow () {
    for (x=1 ; x<5 ; x++) {			// the rows
        for (y=1 ; y<6 ; y++) { 	// the lines
            PicShow("HitInd"+eval(x)+eval(y)+"", hitIndPre[x].src);
        };
    };
};

// hide all Missiles
function AllMissileHide () {
    for (i=1 ; i<4 ; i++) { 	    // the rows
        for (j=1 ; j<6 ; j++) { 	// the lines
            PicShow("Missile"+eval(i)+eval(j)+"", nullPre.src);
        };
    };
};

// show all Missiles
function AllMissileShow () {
    for (i=1 ; i<4 ; i++) {			// the rows
        for (j=1 ; j<6 ; j++) { 	// the lines
            PicShow("Missile"+eval(i)+eval(j)+"", missilePre[i].src);
        };
    };
};

// hide all rising People
function AllPeopleHide () {
    for (i=1 ; i<5 ; i++) { 	    // the rows
        for (j=1 ; j<6 ; j++) { 	// the lines
            PicShow("People"+eval(i)+eval(j)+"", nullPre.src);
        };
    };
};

// show all rising People
function AllPeopleShow () {
    for (i=1 ; i<5 ; i++) {			// the rows
        for (j=1 ; j<6 ; j++) { 	// the lines
            PicShow("People"+eval(i)+eval(j)+"", peoplePre[(i*10+j)].src);
        };
    };
};

// hide all figures on screen
function AllPicturesClear () {
    AllPicturesGameClear();	// hide all game figures
    PicShow("GameOver", nullPre.src);	// hide game over figure
    LivesHide();		// hide all lives in the box
    if (!demo) {		// hide numbers & time colon
    	PicShow("NumColon", nullPre.src);
    	for (i=1 ; i<5 ; i++) PicShow("Num"+eval(i)+"", nullPre.src);
    };
};

// hide all game figures
function AllPicturesGameClear () {
    AllHitIndHide();		// hide all hit indications
    AllMissileHide();		// hide all missiles
    PeopleReset();	// delete all rising People
    ZimHide();	// hide zim
};

// show all figures on screen
function AllPicturesShow () {
    AllHitIndShow();		// show all hit indications
    AllMissileShow();		// show all missiles
    AllPeopleShow();		// show all people
    PicShow("GameOver", gameOverPre.src);	// show game over figure
    for (i=1 ; i<4 ; i++) PicShow("Life"+eval(i)+"", lifePre[i].src);	// show all lives
    if (!demo) {	
	    PicShow("NumColon", numColonPre.src);	// ":"
   		 for (i=1 ; i<5 ; i++) PicShow("Num"+eval(i)+"", numPre[9].src);	// "8"
 	};
    for (i=1 ; i<6 ; i++) PicShow("Zim"+eval(i)+"", zimPre[i].src);		// show zim @ all locations
};

// hide all lives in the box
function LivesHide () {
    for (var i=1 ; i<4 ; i++) PicShow("Life"+eval(i)+"", nullPre.src);
};

// show current lives left
function LivesShow () {
	LivesHide();		// hide all lives in the box
    for (i=1 ; i<(life+1) ; i++) PicShow("Life"+eval(i)+"", lifePre[i].src);	// show all lives left
};

// hide zim
function ZimHide () {
    for (i=1 ; i<6 ; i++) PicShow("Zim"+eval(i)+"", nullPre.src);
};

// show zim @ present position
function ZimShow (z) {
    ZimHide();	// hide zim @ previous position
    PicShow("Zim"+eval(z)+"", zimPre[z].src);	// show zim @ current position
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end preload screen figures & show/hide all of them

//sound functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//make beep-sound
function Beep () {
    PlaySound("beep_", vlm);	// beep sound
};


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end sound functions

//set/reset functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// stop game if playing and reset all ID's
function AllStop () {
    GameReset();    // clear demoID, gameID, missedD, peopleHitIDs & shootID
    TimerReset(); // stop the counter to show the current time
};

// clear demoID, gameID, missedD, peopleHitIDs & shootID
function GameReset () {
   if (demoID) {	// if demo still planned to start stop that plan to avoid double run
        clearTimeout(demoID);
        demoID = null;
    };
    if (gameID) {
        clearTimeout(gameID);	// stop the game
        gameID = null;
    };
    if (missedID) {
        window.clearTimeout(missedID);	// stop miss/game over animation
        missedID = null;
    };
    for (i=1 ; i<5 ; i++) {			// the rows
        for (j=1 ; j<6 ; j++) { 	// the lines
		    if (peopleHitID[(i*10+j)]) {
        		clearTimeout(peopleHitID[(i*10+j)]);	// stop the hit indication animation
        		peopleHitID[(i*10+j)]  = null;
    		};
		 };
    };
    if (shootID) {
        window.clearTimeout(shootID);	// stop the shooting animation
        shootID = null;
    };
};

// delete all missiles
function MissileReset () {
    for (i=1 ; i<4 ; i++) {			// the rows
        for (j=1 ; j<6 ; j++) { 	// the lines
            missile[(i*10+j)] = 0; 
    			missileDown[j] = true;	// missile ended its traject
        };
    };
};

// delete all rising People
function PeopleReset () {
    for (t=1 ; t<5 ; t++) {		// the linnes
        PeopleRowReset(t);     // delete rising People from row "t"
    };
    PeopleShow();      // show all People @ present state
};

// delete rising People from row
function PeopleRowReset (row) {
    for (u=0 ; u<6 ; u++) {	// from all positions in row
        peoplePresent[(row*10+u)] = 0;	// remove people from position
    };
};

// clear all pictures & variables
function ResetAll () {
    AllStop();  // stop game if playing and reset all ID's
    for (i=1 ; i<5 ; i++) for (j=1 ; j<6 ; j++) {		// reset array of all hit indication and animation
    	hitSequence[(i*10+j)] =0;
    };
    peopleOutRow = 0;		// no people reached zim
    MissileReset();	// delete all missiles
    AllPicturesClear ();     // hide all figures on screen
    PeopleReset();	// delete all rising People
    gameOver = false;
    sequence = 1;		// reset sequence for demo, game intro, miss & game over animation
    peopleGotYou = false;       // reset possible surfaced People
    missed = false;
    pause = false;
};

// reset speed according to the current score
function SpeedReset () {
    gameSpeed = gameSpeedMinimum - Math.round(score%1000/25) - Math.floor(score/50) - Math.floor(score/1000);
    gameSpeed = gameSpeed>gameSpeedMaximum?gameSpeed:gameSpeedMaximum;
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end set/reset functions

//game functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// show demo
function Demo () {
    if (demoID) {	// if demo still planned to start stop that plan to avoid double run
        clearTimeout(demoID);
        demoID = null;
    };
    switch (sequence) {		// sequence for demo animation
        case 1:
        		AllPicturesShow();		// show all figures on screen
            break;
        case 2:
        		AllPicturesClear();     // hide all figures on screen
            break;
        case 3:
        		AllPicturesShow();		// show all figures on screen
            break;
        case 4:
        		AllPicturesClear();     // hide all figures on screen
            break;
        case 5:
        		AllPicturesShow();		// show all figures on screen
            break;
        case 6:
        		AllPicturesClear();     // hide all figures on screen
            break;
        case 7:
            ZimShow(3);		// show zim @ third position
        		for (i=1 ; i<4 ; i++) PicShow("Life"+eval(i)+"", lifePre[i].src);	// show all lives
        		PicShow("People"+eval(4)+eval(1)+"", peoplePre[(4*10+1)].src);
        		PicShow("People"+eval(4)+eval(2)+"", peoplePre[(4*10+2)].src);
        		PicShow("People"+eval(3)+eval(2)+"", peoplePre[(3*10+2)].src);
        		PicShow("People"+eval(4)+eval(3)+"", peoplePre[(4*10+3)].src);
        		PicShow("People"+eval(4)+eval(5)+"", peoplePre[(4*10+5)].src);
        		PicShow("People"+eval(3)+eval(5)+"", peoplePre[(3*10+5)].src);
        		PicShow("People"+eval(2)+eval(5)+"", peoplePre[(2*10+5)].src);
            break;
        case 8: case 9:
            break;
        case 10:
            ZimShow(4);		// show zim @ fourth position
        		PicShow("People"+eval(3)+eval(3)+"", peoplePre[(3*10+3)].src);
            break;
        case 11:
            ZimShow(5);		// show zim @ fifth position
            break;
        case 12:
        		PicShow("People"+eval(3)+eval(1)+"", peoplePre[(3*10+1)].src);
        		PicShow("Missile"+eval(1)+eval(5)+"", missilePre[1].src);
            break;
        case 13:
            ZimShow(4);		// show zim @ fourth position
        		PicShow("People"+eval(2)+eval(5)+"", nullPre.src);
        		PicShow("Missile"+eval(1)+eval(5)+"", nullPre.src);
        		PicShow("HitInd"+eval(2)+eval(5)+"", hitIndPre[2].src);
            break;
        case 14:
            ZimShow(3);		// show zim @ third position
         		PicShow("HitInd"+eval(2)+eval(5)+"", nullPre.src);
       		PicShow("Missile"+eval(1)+eval(3)+"", missilePre[1].src);
            break;
        case 15:
            ZimShow(2);		// show zim @ second position
        		PicShow("Missile"+eval(1)+eval(3)+"", nullPre.src);
        		PicShow("Missile"+eval(2)+eval(3)+"", missilePre[1].src);
        		PicShow("Missile"+eval(1)+eval(2)+"", missilePre[1].src);
        		PicShow("HitInd"+eval(2)+eval(5)+"", hitIndPre[2].src);
            break;
        case 16:
            ZimShow(1);		// show zim @ first position
        		PicShow("People"+eval(3)+eval(3)+"", nullPre.src);
        		PicShow("Missile"+eval(2)+eval(3)+"", nullPre.src);
        		PicShow("Missile"+eval(1)+eval(2)+"", nullPre.src);
        		PicShow("HitInd"+eval(2)+eval(5)+"", nullPre.src);
        		PicShow("HitInd"+eval(2)+eval(5)+"", nullPre.src);
        		PicShow("People"+eval(2)+eval(1)+"", peoplePre[(2*10+1)].src);
        		PicShow("People"+eval(4)+eval(4)+"", peoplePre[(4*10+4)].src);
        		PicShow("Missile"+eval(1)+eval(1)+"", missilePre[1].src);
        		PicShow("Missile"+eval(2)+eval(2)+"", missilePre[2].src);
        		PicShow("HitInd"+eval(3)+eval(3)+"", hitIndPre[3].src);
            break;
        case 17:	
        		PicShow("People"+eval(2)+eval(1)+"", nullPre.src);
        		PicShow("People"+eval(3)+eval(2)+"", nullPre.src);
        		PicShow("Missile"+eval(1)+eval(1)+"", nullPre.src);
        		PicShow("Missile"+eval(2)+eval(2)+"", nullPre.src);
        		PicShow("HitInd"+eval(3)+eval(3)+"", nullPre.src);
        		PicShow("HitInd"+eval(2)+eval(1)+"", hitIndPre[2].src);
        		PicShow("HitInd"+eval(3)+eval(2)+"", hitIndPre[3].src);
            break;
        case 18:
        		PicShow("HitInd"+eval(2)+eval(1)+"", nullPre.src);
        		PicShow("HitInd"+eval(3)+eval(2)+"", nullPre.src);
        		PicShow("HitInd"+eval(3)+eval(3)+"", hitIndPre[3].src);
            break;
        case 19:
            ZimShow(2);		// show zim @ second position
        		PicShow("HitInd"+eval(3)+eval(3)+"", nullPre.src);
        		PicShow("HitInd"+eval(2)+eval(1)+"", hitIndPre[2].src);
        		PicShow("HitInd"+eval(3)+eval(2)+"", hitIndPre[3].src);
            break;
        case 20:
            ZimShow(3);		// show zim @ third position
        		PicShow("HitInd"+eval(2)+eval(1)+"", nullPre.src);
        		PicShow("HitInd"+eval(3)+eval(2)+"", nullPre.src);
        		PicShow("People"+eval(2)+eval(5)+"", peoplePre[(2*10+5)].src);
        		PicShow("Missile"+eval(1)+eval(3)+"", missilePre[1].src);
            break;
        case 21:
        		PicShow("Missile"+eval(1)+eval(3)+"", nullPre.src);
        		PicShow("Missile"+eval(2)+eval(3)+"", missilePre[2].src);
            break;
        case 22:
        		PicShow("Missile"+eval(2)+eval(3)+"", nullPre.src);
        		PicShow("Missile"+eval(3)+eval(3)+"", missilePre[3].src);
            break;
        case 23:
        		PicShow("People"+eval(4)+eval(3)+"", nullPre.src);
        		PicShow("Missile"+eval(3)+eval(3)+"", nullPre.src);
        		PicShow("HitInd"+eval(4)+eval(3)+"", hitIndPre[4].src);
            break;
        case 24:
            ZimShow(2);		// show zim @ second position
        		PicShow("People"+eval(1)+eval(5)+"", peoplePre[(1*10+5)].src);
        		PicShow("HitInd"+eval(4)+eval(3)+"", nullPre.src);
            break;
        case 25:
        		PicShow("Missile"+eval(1)+eval(2)+"", missilePre[1].src);
        		PicShow("HitInd"+eval(4)+eval(3)+"", hitIndPre[4].src);
            break;
        case 26:
        		PicShow("Missile"+eval(1)+eval(2)+"", nullPre.src);
        		PicShow("HitInd"+eval(4)+eval(3)+"", nullPre.src);
        		PicShow("Missile"+eval(2)+eval(2)+"", missilePre[2].src);
            break;
        case 27:
        		PicShow("Missile"+eval(2)+eval(2)+"", nullPre.src);
        		PicShow("Missile"+eval(3)+eval(2)+"", missilePre[3].src);
            break;
        case 28:
        		PicShow("People"+eval(4)+eval(2)+"", nullPre.src);
        		PicShow("Missile"+eval(3)+eval(2)+"", nullPre.src);
        		PicShow("HitInd"+eval(4)+eval(2)+"", hitIndPre[4].src);
            break;
        case 29:
        		PicShow("HitInd"+eval(4)+eval(2)+"", nullPre.src);
        		PicShow("People"+eval(2)+eval(1)+"", peoplePre[(2*10+1)].src);
            break;
        case 30:
        		PicShow("HitInd"+eval(4)+eval(2)+"", hitIndPre[4].src);
            break;
        case 31:
            ZimShow(3);		// show zim @ third position
        		PicShow("HitInd"+eval(4)+eval(2)+"", nullPre.src);
            break;
        case 32:
            ZimShow(4);		// show zim @ fourth position
            break;
        case 33:
        		LivesHide();	// hide all lives in the box
        		ZimHide();	// hide zim
        		PicShow("People"+eval(1)+eval(5)+"", nullPre.src);
         		PicShow("People"+eval(2)+eval(1)+"", nullPre.src);
        		PicShow("People"+eval(3)+eval(1)+"", nullPre.src);
        		PicShow("People"+eval(3)+eval(5)+"", nullPre.src);
        		PicShow("People"+eval(4)+eval(1)+"", nullPre.src);
        		PicShow("People"+eval(4)+eval(4)+"", nullPre.src);
        		PicShow("GameOver", gameOverDownPre.src);	// show game over figure with down buzz
           break;
        case 34:
        		PicShow("People"+eval(2)+eval(5)+"", nullPre.src);
        		PicShow("People"+eval(4)+eval(5)+"", nullPre.src);
        		PicShow("People"+eval(1)+eval(5)+"", peoplePre[(1*10+5)].src);
        		PicShow("People"+eval(3)+eval(5)+"", peoplePre[(3*10+5)].src);
        		PicShow("GameOver", gameOverUpPre.src);	// show game over figure with up buzz
            break;
        case 35:
        		PicShow("People"+eval(1)+eval(5)+"", nullPre.src);
        		PicShow("People"+eval(3)+eval(5)+"", nullPre.src);
        		PicShow("People"+eval(2)+eval(5)+"", peoplePre[(2*10+5)].src);
        		PicShow("People"+eval(4)+eval(5)+"", peoplePre[(4*10+5)].src);
        		PicShow("GameOver", gameOverDownPre.src);	// show game over figure with down buzz
            break;
        case 36:
        		PicShow("People"+eval(2)+eval(5)+"", nullPre.src);
        		PicShow("People"+eval(4)+eval(5)+"", nullPre.src);
        		PicShow("People"+eval(1)+eval(5)+"", peoplePre[(1*10+5)].src);
        		PicShow("People"+eval(3)+eval(5)+"", peoplePre[(3*10+5)].src);
        		PicShow("GameOver", gameOverUpPre.src);	// show game over figure with up buzz
            break;
        case 37:
        		PicShow("People"+eval(1)+eval(5)+"", nullPre.src);
        		PicShow("People"+eval(3)+eval(5)+"", nullPre.src);
        		PicShow("People"+eval(2)+eval(5)+"", peoplePre[(2*10+5)].src);
        		PicShow("People"+eval(4)+eval(5)+"", peoplePre[(4*10+5)].src);
        		PicShow("GameOver", gameOverDownPre.src);	// show game over figure with down buzz
            break;
        case 38:
        		PicShow("People"+eval(2)+eval(5)+"", nullPre.src);
        		PicShow("People"+eval(4)+eval(5)+"", nullPre.src);
        		PicShow("People"+eval(1)+eval(5)+"", peoplePre[(1*10+5)].src);
        		PicShow("People"+eval(3)+eval(5)+"", peoplePre[(3*10+5)].src);
        		PicShow("GameOver", gameOverUpPre.src);	// show game over figure with up buzz
            break;
        case 39:
        		PicShow("People"+eval(1)+eval(5)+"", nullPre.src);
        		PicShow("People"+eval(3)+eval(5)+"", nullPre.src);
        		PicShow("People"+eval(2)+eval(5)+"", peoplePre[(2*10+5)].src);
        		PicShow("People"+eval(4)+eval(5)+"", peoplePre[(4*10+5)].src);
        		PicShow("GameOver", gameOverDownPre.src);	// show game over figure with down buzz
            break;
        case 40:
        		PicShow("People"+eval(2)+eval(5)+"", nullPre.src);
        		PicShow("People"+eval(4)+eval(5)+"", nullPre.src);
        		PicShow("People"+eval(1)+eval(5)+"", peoplePre[(1*10+5)].src);
        		PicShow("People"+eval(3)+eval(5)+"", peoplePre[(3*10+5)].src);
        		PicShow("GameOver", gameOverUpPre.src);	// show game over figure with up buzz
            break;
        case 41:
        		PicShow("People"+eval(1)+eval(5)+"", nullPre.src);
        		PicShow("People"+eval(3)+eval(5)+"", nullPre.src);
        		PicShow("People"+eval(2)+eval(5)+"", peoplePre[(2*10+5)].src);
        		PicShow("People"+eval(4)+eval(5)+"", peoplePre[(4*10+5)].src);
        		PicShow("GameOver", gameOverDownPre.src);	// show game over figure with down buzz
            break;
        case 42:
        		PicShow("People"+eval(2)+eval(5)+"", nullPre.src);
        		PicShow("People"+eval(4)+eval(5)+"", nullPre.src);
        		PicShow("People"+eval(1)+eval(5)+"", peoplePre[(1*10+5)].src);
        		PicShow("People"+eval(3)+eval(5)+"", peoplePre[(3*10+5)].src);
        		PicShow("GameOver", gameOverUpPre.src);	// show game over figure with up buzz
            break;
        case 43:
        		PicShow("People"+eval(1)+eval(5)+"", nullPre.src);
        		PicShow("People"+eval(3)+eval(5)+"", nullPre.src);
        		PicShow("GameOver", nullPre.src);	// hide game over figure
            break;
        default: 
    };
    if (sequence<45) sequence++
    else sequence = 1;		// reset sequence for demo animation
    demoID = window.setTimeout("Demo()", 250);	// next step after quarter of a second  
};

// next move of game
function GameGo () {
    var newPeople = false;        // defines if new People are added to the scene 
    var counter = 0;    // loop counter to avoid loop from getting stuck by running for ever if last add was delayed
    if (gameID) {
        clearTimeout(gameID);	// stop the game's possible double call
        gameID = null;
    };
    if (!missed) {
	    if (!pause) {
			  PeopleAdd();   // people moving up one position @ random row
      		  PeopleShow();  // show all people present
	    }; 
   		 gameID = window.setTimeout("GameGo()", gameSpeed);    // next step in gameSpeed milliseconds
	};
};

// resume game after pause for indicating missed People
function GameGoNext () {
    missed = false;	// reset missed indication to resume or end game
    nomove = true;	// no move allowed during game intro
    if (gameID) {
        clearTimeout(gameID);	// stop the game if running
        gameID = null;
    };
    if (shootID) {
        clearTimeout(shootID);	// reset ID for shooting animation delay if exists
        shootID = null;
    };
    sequence = 1;		// reset sequence for demo, game intro, miss & game over animation
    gameID = window.setTimeout("MainGameIntro()", gameSpeed);        // start game intro in gameSpeed milliseconds
};

// set all game settings
function GameSet () {
   ResetAll();		// clear all pictures & variables
    gameSpeed = gameSpeedMinimum;       // start @ lowest speed (in milliseconds)
    pos = 3;	// zim starts @ 3rd position
    MainPicturesGame();	// show default pictures @ start of the game & show score
};

// reset lives & show them
function LivesReset () {
    life = 3;	// all lives available
    LivesShow();	// show current lives left
    missed = false;	// no misses in progress
};

// button pressed to play the game
function MainGameA () {
    if (game!=1) {   // if not already game A or B playing
    	AllPicturesClear ();     // hide all figures on screen
        demo = false;		// once this key is hit, the demo is turned off
        if (demoID) {
            clearTimeout(demoID);   // prevent demo from restarting if planned
            demoID = null;
        		TimerReset();
        };
        HighScoreShow();        // show highest score since this browser tab was opened
        sequence = 1;		// reset sequence for demo, game intro, miss & game over animation
    };
};

// button pressed to play game A
function MainGameAGo () {
    if (game!=1) {   // if not already game A or B playing
    	LivesReset(); // reset lives & show them
    	score = 0;  // reset score
      game = 1; // gameA
    	GameGoNext();	// start game
	};
};

// button pressed to play game A
function MainGameAGoOn () {
    if (!pause) {
    	nomove = false;		// to allow moves after game intro
        GameSet(); // set all game settings
        missed = false;
        ScoreShow(score);	// show current score
        gameID = window.setTimeout("GameGo()", gameSpeed);    // start running game in  half a second
    } else gameID = window.setTimeout("GameGo()", 250);    // try again in a quarter of a second 
};

// game intro animation 
function MainGameIntro () {
    if (gameID) {
        clearTimeout(gameID);	// stop the game's possible double call
        gameID = null;
    };
	if (!pause) {
   		 switch (sequence) {		// sequence for game intro animation
      		  case 1:
        			AllPicturesShow();		// show all figures on screen
            		break;
	        case 2:
   		     		AllPicturesClear();     // hide all figures on screen
      		      break;
	        case 3:
   		     		AllPicturesShow();		// show all figures on screen
      		      break;
	        case 4:
   		     		AllPicturesClear();     // hide all figures on screen
      		      break;
	        case 5:
   		     		AllPicturesShow();		// show all figures on screen
      		      break;
	        case 6:
   		     		AllPicturesClear();     // hide all figures on screen
      		      break;
	        case 7:
   		         break;
      		  default: 
	   		 };
		    if (sequence<7) {
    			sequence++
		   		 gameID = window.setTimeout("MainGameIntro()", 250);	// next step after quarter of a second  
		    } else gameID = window.setTimeout("MainGameAGoOn()", 250);	// next step after quarter of a second  
	} else gameID = window.setTimeout("MainGameIntro()", 250);	// try again in a quarter of a second 
};

// stop game, clear all and animate game over using people out position
function MainGameOver (peopleOutRow) {
    GameReset();	// stop game if playing and reset all ID's
	if (!pause) {
    	sequence = 1;		// reset sequence for demo, game intro, miss & game over animation
	    MainGameOverAnimation (peopleOutRow);	// animate miss or game over using peolpe out position
   		 demoID = window.setTimeout("MainTimeStart()", 60000);	// start demo after a minute  
	} else missedID = window.setTimeout("MainGameOver("+peopleOutRow+")", 250);	// try again in a quarter of a second;
};

// animate miss or game over using peolpe out position
function MainGameOverAnimation (peopleOutRow) {
    if (missedID) {
        clearTimeout(missedID);	// stop the game
        missedID = null;
    };
	if (!pause) {
		AllPicturesGameClear();	// hide all game figures
		switch (sequence) {		// sequence for game over animation
   		     case 1:
      		  		if (life==0)PicShow("GameOver", gameOverDownPre.src);	// show game over figure with down buzz
         		  break;
 	       case 2:
   	     		PicShow("People"+eval(2)+eval(peopleOutRow)+"", nullPre.src);
        		PicShow("People"+eval(4)+eval(peopleOutRow)+"", nullPre.src);
        		PicShow("People"+eval(1)+eval(peopleOutRow)+"", peoplePre[(1*10+5)].src);
        		PicShow("People"+eval(3)+eval(peopleOutRow)+"", peoplePre[(3*10+5)].src);
        		if (life==0)PicShow("GameOver", gameOverUpPre.src);	// show game over figure with up buzz
            break;
 	       case 3:
        		PicShow("People"+eval(1)+eval(peopleOutRow)+"", nullPre.src);
        		PicShow("People"+eval(3)+eval(peopleOutRow)+"", nullPre.src);
        		PicShow("People"+eval(2)+eval(peopleOutRow)+"", peoplePre[(2*10+5)].src);
        		PicShow("People"+eval(4)+eval(peopleOutRow)+"", peoplePre[(4*10+5)].src);
        		ScoreHide();
        		if (life==0)PicShow("GameOver", gameOverDownPre.src);	// show game over figure with down buzz
            break;
	       case 4:
        		PicShow("People"+eval(2)+eval(peopleOutRow)+"", nullPre.src);
        		PicShow("People"+eval(4)+eval(peopleOutRow)+"", nullPre.src);
        		PicShow("People"+eval(1)+eval(peopleOutRow)+"", peoplePre[(1*10+5)].src);
        		PicShow("People"+eval(3)+eval(peopleOutRow)+"", peoplePre[(3*10+5)].src);
        		ScoreUnHide();
        		if (life==0)PicShow("GameOver", gameOverUpPre.src);	// show game over figure with up buzz
            break;
 	       case 5:
        		PicShow("People"+eval(1)+eval(peopleOutRow)+"", nullPre.src);
        		PicShow("People"+eval(3)+eval(peopleOutRow)+"", nullPre.src);
        		PicShow("People"+eval(2)+eval(peopleOutRow)+"", peoplePre[(2*10+5)].src);
        		PicShow("People"+eval(4)+eval(peopleOutRow)+"", peoplePre[(4*10+5)].src);
        		ScoreHide();
        		if (life==0)PicShow("GameOver", gameOverDownPre.src);	// show game over figure with down buzz
            break;
	       case 6:
        		PicShow("People"+eval(2)+eval(peopleOutRow)+"", nullPre.src);
        		PicShow("People"+eval(4)+eval(peopleOutRow)+"", nullPre.src);
        		PicShow("People"+eval(1)+eval(peopleOutRow)+"", peoplePre[(1*10+5)].src);
        		PicShow("People"+eval(3)+eval(peopleOutRow)+"", peoplePre[(3*10+5)].src);
        		ScoreUnHide();
        		if (life==0) PicShow("GameOver", gameOverUpPre.src);	// show game over figure with up buzz
            break;
	       case 7:
        		PicShow("People"+eval(1)+eval(peopleOutRow)+"", nullPre.src);
        		PicShow("People"+eval(3)+eval(peopleOutRow)+"", nullPre.src);
        		PicShow("People"+eval(2)+eval(peopleOutRow)+"", peoplePre[(2*10+5)].src);
        		PicShow("People"+eval(4)+eval(peopleOutRow)+"", peoplePre[(4*10+5)].src);
        		ScoreHide();
        		if (life==0) PicShow("GameOver", gameOverDownPre.src);	// show game over figure with down buzz
            break;
	       case 8:
        		PicShow("People"+eval(2)+eval(peopleOutRow)+"", nullPre.src);
        		PicShow("People"+eval(4)+eval(peopleOutRow)+"", nullPre.src);
        		PicShow("People"+eval(1)+eval(peopleOutRow)+"", peoplePre[(1*10+5)].src);
        		PicShow("People"+eval(3)+eval(peopleOutRow)+"", peoplePre[(3*10+5)].src);
        		ScoreUnHide();
        		if (life==0) PicShow("GameOver", gameOverUpPre.src);	// show game over figure with up buzz
            break;
	       case 9:
        		PicShow("People"+eval(1)+eval(peopleOutRow)+"", nullPre.src);
        		PicShow("People"+eval(3)+eval(peopleOutRow)+"", nullPre.src);
        		PicShow("People"+eval(2)+eval(peopleOutRow)+"", peoplePre[(2*10+5)].src);
        		PicShow("People"+eval(4)+eval(peopleOutRow)+"", peoplePre[(4*10+5)].src);
        		ScoreHide();
        		if (life==0) PicShow("GameOver", gameOverDownPre.src);	// show game over figure with down buzz
            break;
	       case 10:
        		PicShow("People"+eval(2)+eval(peopleOutRow)+"", nullPre.src);
        		PicShow("People"+eval(4)+eval(peopleOutRow)+"", nullPre.src);
        		PicShow("People"+eval(1)+eval(peopleOutRow)+"", peoplePre[(1*10+5)].src);
        		PicShow("People"+eval(3)+eval(peopleOutRow)+"", peoplePre[(3*10+5)].src);
        		ScoreUnHide();
        		if (life==0) PicShow("GameOver", gameOverUpPre.src);	// show game over figure with up buzz
            break;
	       case 11:
        		PicShow("People"+eval(1)+eval(peopleOutRow)+"", nullPre.src);
        		PicShow("People"+eval(3)+eval(peopleOutRow)+"", nullPre.src);
        		if (life==0) {
        			PicShow("GameOver", gameOverPre.src);	// show full game over figure
        			PlaySound("gameover_", vlm);	// sound for game over
				}
            break;
	       default: 
	    };
	    if (sequence<11) {
   		 	sequence++
	   		 missedID = window.setTimeout("MainGameOverAnimation("+peopleOutRow+")", 250);	// next step after quarter of a second  
	    } else if (life>0) { 
    		gameID = window.setTimeout("GameGoNext ()", 250);	// resume game after pause for indicating missed People
		} else {
			game = 0;
			missed = false;
		};
	} else missedID = window.setTimeout("MainGameOverAnimation("+peopleOutRow+")", 250);	// next step after quarter of a second  
};

// show default pictures @ start of the game & show score
function MainPicturesGame () {
    mainPicturesGameSetup = 1    // to prevent already more people added during MainPicturesGame()
    ZimShow(pos);     // show zim his current position
    for (x=1 ; x<8 ; x++) {		// add the first 7 random people to start the game
    	PeopleAdd();	// people moving up one position @ random row
    };
    ScoreShow(score);	// show current score
    PeopleShow();  // show all People present
    LivesShow();	// show current lives left
    mainPicturesGameSetup = 0;	// from now on, more people can be added because game started
};

// show & animate surfaced people
function Miss (peopleOutRow) {
    if (game==1) {	// if game playing
    	PlaySound("miss_", vlm);	// sound for miss
		missed = true;
        if (demoID) {
            clearTimeout(demoID);	// stop the game
            demoID = null;
        };
        life--;
        LivesShow();	// show current lives left
		if (life>0) {
			   sequence = 1;		// reset sequence for demo, game intro, miss & game over animation
			   AllStop();
        		MainGameOverAnimation(peopleOutRow);	// animate miss or game over using peolpe out position
        } else {
            MainGameOver(peopleOutRow);	// stop game, clear all and animate game over using people out position
        };
    };
};

// check if missile fired on that row
function Missile (row) {
	var missilePresent = 0;	// no missile found yet
   // for (i=1 ; i<5 ; i++) { 	// lines
   for (i=1 ; i<5 ; i++) { 	// lines
		if (missile[(i*10+row)]) {		// missile found
			missilePresent++	// add to count
		};
	};
	return missilePresent;	// counted missiles on that row
};

// show leading zeroes
function n(n){
    return n>9?""+n:"0"+n;
};

// pause/unpause the game
function Pause () {
    if (game==1) pause = !pause;	// set/unset pause if game is running
};

// people moving up one position @ random row
function PeopleAdd () {
    var addRow = Math.floor(5*Math.random())+1		// choose row to add people
    var addLine = 5;     // startposition to possibly add people
    if (!pause&&!missed) {	// if game running
        do { 
            addLine--;	// next line
        } 
        while (peoplePresent[(addLine*10+addRow)]&&addLine>0);		// till empty spot found on that row
        if ((addLine>0&&!mainPicturesGameSetup)||(addLine>1&&mainPicturesGameSetup)) {		// if people can be added
	        if (!Missile(addRow)&&!hitSequence[(addLine*10+addRow)]&&(addLine<4?peoplePresent[((addLine+1)*10+addRow)]:1)) { 	// if no shooting happening on row
           		peoplePresent[(addLine*10+addRow)] = 1;		// place people on this position
          	};
         } else if (!mainPicturesGameSetup) {		// if row full & game setup not running
	    	missed = true;
	    	peopleOutRow = addRow;		// people reached zim @ this position
	    	Miss(peopleOutRow);		// engage miss indication & animation
	    };
	};
};

// blink hitIndication
function PeopleHit (missilePos,shooterPos) {
    if (peopleHitID[(missilePos*10+shooterPos)]) {		// to avoid double call
        clearTimeout(peopleHitID[(missilePos*10+shooterPos)]);	// stop the game
        peopleHitID[(missilePos*10+shooterPos)]  = null;
    };
   if (!missed) {
	   if (!pause) {
   			 switch (hitSequence[(missilePos*10+shooterPos)]) {		  // progress people's hit indication animation
	      	 case 1:
	      			peoplePresent[(missilePos*10+shooterPos)] = 0;		// remove hit people
        			PicShow("HitInd"+eval(missilePos)+eval(shooterPos)+"", hitIndPre[missilePos].src);	// show hit indication on screen
   			   		PicShow("People"+eval(missilePos)+eval(shooterPos)+"", nullPre.src);	// hide hit people on screen
            		break;
        		case 2:
      		   		PicShow("HitInd"+eval(missilePos)+eval(shooterPos)+"", nullPre.src);		// hide hit indication on screen
	            break;
        		case 3:
      		  		PicShow("HitInd"+eval(missilePos)+eval(shooterPos)+"", hitIndPre[missilePos].src);	// show hit indication on screen
   		         break;
	        	case 4:
        			PicShow("HitInd"+eval(missilePos)+eval(shooterPos)+"", nullPre.src);		// hide hit indication on screen
      		      break;
        		case 5:
   		   			if (missilePos>1) missile[((missilePos-1)*10+shooterPos)] = 0; // not earlier than here for overlap to prevent PeopleAdd() while hit indication animation
   		         break;
   		     	default: 
		    };
		    if (hitSequence[(missilePos*10+shooterPos)]<5) {		// if sequence running
   			 	 hitSequence[(missilePos*10+shooterPos)]++	// next sequence
	   			 peopleHitID[(missilePos*10+shooterPos)] = window.setTimeout("PeopleHit ("+missilePos+","+shooterPos+")", 250);	// next step after quarter of a second  
   			 } else hitSequence[(missilePos*10+shooterPos)] = 0;	//  reset sequence for hit indication animation
		} else peopleHitID[(missilePos*10+shooterPos)] = window.setTimeout("PeopleHit ("+missilePos+","+shooterPos+")", 250);	// next step after quarter of a second;
	};
};

// count the number of people present @ line peoplePresentLine
function PeoplePresentLine (peoplePresentLine) {
    var presentPeople = 0;	// no people counted on this line
    for (i=1 ; i<5 ; i++) {
        if (peoplePresent[(i*10+peoplePresentLine)]) peoplePresent++;	// add if found
    };
    return presentPeople;
};

// show all people present
function PeopleShow () {
    for (i=1 ; i<5 ; i++) { 			// the rows
        for (j=1 ; j<6 ; j++) { 		// the lines
            if (peoplePresent[(i*10+j)]) PicShow("People"+eval(i)+eval(j)+"", peoplePre[(i*10+j)].src)		// show if present
            else PicShow("People"+eval(i)+eval(j)+"", nullPre.src);		// hide if not
        };
    };	
};

// shoot missile @ this position
function Shoot (pos) {
    if (game==1) {	// if game playing
		  // PlaySound("shoot_", vlm);	// click sound for push button
        ShootMissile(1,pos);		// shoot missile animation
    };
};

// shoot missile animation
function ShootMissile (missilePos,shooterPos) {
    if (!missed) {	// if not misssed
	    if (!pause) {	// if not paused
		    if (game==1) {	// if game playing
      			if (missilePos>1) {
      				PicShow("Missile"+eval(missilePos-1)+eval(shooterPos)+"", nullPre.src);		// hide previous positioned missile on screen if present 
   			   	};
      			if (missilePos<4&&!peoplePresent[(missilePos*10+shooterPos)]) {		// if no people encountered or missile hit the bottom
   		   			if (peoplePresent[((missilePos+1)*10+shooterPos)]) PlaySound("hit"+shooterPos+"_", vlm);	// sound for hit
      				if (missilePos>1) missile[((missilePos-1)*10+shooterPos)] = 0; // remove previous positioned missile if present
	      			PicShow("Missile"+eval(missilePos)+eval(shooterPos)+"", missilePre[missilePos].src);		// show current positioned missile
	   		   		missile[(missilePos*10+shooterPos)] = 1; 			// set current positioned missile
   		   			shootID  = window.setTimeout("ShootMissile ("+(missilePos+1)+","+(shooterPos)+")", (gameSpeed/3));	// go to next position
	   		   	} else {
      				if (missilePos<6&&peoplePresent[(missilePos*10+shooterPos)]&&!hitSequence[(missilePos*10+shooterPos)]) {		// if people hit
      					PeopleHit(missilePos,shooterPos);	// initiate people been hit
	      				ScoreAdd(1);	// one point earned
		      		} else {
      					if (missilePos>1) missile[((missilePos-1)*10+shooterPos)] = 0; // reset missile presence not earlier than here for overlap to prevent PeopleAdd())
      				};
   				 	missileDown[shooterPos] = true;	// missile ended its traject
		      	}
   			 };
   		 } else shootID  = window.setTimeout("ShootMissile ("+(missilePos)+","+(shooterPos)+")", (gameSpeed/3));	// try again if paused
	};
};

// speeds up the game with given value
function SpeedUp (speed) {
    var prevSpeed = gameSpeed;  // for logging...
    if (gameSpeed>gameSpeedMaximum) gameSpeed -= speed; // if not @ max speed, speed up
};


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end game functions
