/*------------------------------------------------------------------sound------------------------------------------------------------------*/

function PlaySoundAlways (name, vol){
	var playPromise;	// play-preset indicator
	name+="wav";
		document.getElementById(name).muted = false;
	playPromise = document.getElementById(name).play();
	if (vol) { 
		document.getElementById(name).volume = vol;
	}
	if (playPromise !== undefined) {
		playPromise.then(_ => {
		  // playback started!
		})
		.catch(error => {
		  // play was prevented
		});
	}
}

function PlaySound (name, vol){
	if ( prefSound&&!demo ) {
		PlaySoundAlways (name, vol);
	}
}

function PlaySoundEvenIfDemo (name, vol){
	if ( prefSound ) {
		PlaySoundAlways (name, vol);
	}
}

function StopSound (name, vol){
	var playPromise;	// play-preset indicator
	name+="wav";
	playPromise = document.getElementById(name).pause();
	if (vol) { 
		document.getElementById(name).volume = vol;
	}
	if (playPromise !== undefined) {
		playPromise.then(_ => {
		  // playback stopped!
		})
		.catch(error => {
		  // stopping was prevented
		});
	}
}

/*------------------------------------------------------------------sound------------------------------------------------------------------*/
